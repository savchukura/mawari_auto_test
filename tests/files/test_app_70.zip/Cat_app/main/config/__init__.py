import os
import sys

from . import images
from .general import *


def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)


class Config:
    TMP_DIRECTORY = 'tmp'
    APP_WORKING_DIRECTORY = os.path.curdir

    # DICTIONARIES_DIRECTORY = os.path.join(APP_WORKING_DIRECTORY, 'static', 'dictionaries')

    IMAGE_SERVICE_URL = os.environ.get('IMAGE_SERVICE_URL', 'http://stage.catlabs.zpoken.io:6011')
    IMAGE_API_KEY = os.environ.get('IMAGE_SERVICE_KEY', 'key')

    BACK_API_URL = os.environ.get('BACK_API_URL', 'https://dev.catlabs.zpoken.io')
    BACK_API_KEY = os.environ.get('BACK_API_KEY', 'key')

    SQLALCHEMY_DATABASE_URI = f'sqlite:///{resource_path("data.db")}?check_same_thread=False'
    SQLALCHEMY_TRACK_MODIFICATIONS = False  # silence the deprecation warning

    ETHERSCAN_API_KEY = "9414EJG8SZIX3J3PWAAG1HBI2EQQZJG4PZ"
    POLYGON_API_KEY = "wCQUQctcSjfdDJoYALelkvC3z7v6Np2O"

    WALLET_SERVICE_URL = "https://api.etherscan.io/api"
    DICTIONARIES_DIRECTORY = resource_path(os.path.join('static', 'dictionaries'))
