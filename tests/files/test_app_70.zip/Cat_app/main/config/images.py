import os

DEFAULT_ASSETS_DIR_PATH = os.path.join(
    os.path.curdir,'static',  'assets', 'images',
)

DEFAULT_CARD_ICON_PATH = os.path.join(DEFAULT_ASSETS_DIR_PATH, 'bg_image.png')
# DEFAULT_CARD_ICON_PATH = os.path.join(DEFAULT_ASSETS_DIR_PATH, 'bg_image.png')
