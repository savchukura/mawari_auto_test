crypto_apps = [
    'electrum',
    'exodus',
    'ledger',
    'wasabi'
]
