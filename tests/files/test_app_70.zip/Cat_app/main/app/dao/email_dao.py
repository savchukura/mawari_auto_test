from app.dao.base_dao import BaseDAO
from app.models import Email

email_dao = BaseDAO(Email)
