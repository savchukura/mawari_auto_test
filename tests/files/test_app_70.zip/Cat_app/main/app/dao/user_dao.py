from app.models import User


class UserDAO:
    ...
