from app.dao.base_dao import BaseDAO
from app.models import Case

case_dao = BaseDAO(Case)
