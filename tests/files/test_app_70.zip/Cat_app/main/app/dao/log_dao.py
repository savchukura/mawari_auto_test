from app.dao.base_dao import BaseDAO
from app.models import Log

log_dao = BaseDAO(model=Log)
