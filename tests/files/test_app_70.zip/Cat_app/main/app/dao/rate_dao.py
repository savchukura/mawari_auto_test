from datetime import datetime, timedelta

from app.models import Rate
from utils import coingeko

from app import Session
class RateDAO:
    SYMBOLS = [
        'ETH', 'DAI', 'USDT', 'USDC', 'BNB', 'BUSD', 'MATIC', 'SHIB', 'stETH', 'UNI', 'WBTC', 'LINK', 'QNT', 'APE',
        'XCN', 'SAND', 'CHZ', 'USDP', 'TUSD', 'LDO', 'GRT', 'FTM', 'PAXG', 'SNX', 'ENJ', 'BAT', 'AMP']

    def __init__(
            self,
    ):
        self.session = Session()

    def get_all(self):
        query = self.session.query(Rate)
        rates = {r.from_currency_symbol: r.rate for r in query}
        #todo: caching
        # if query.first() and datetime.now() - query.first().created_at > timedelta(days=1):
        #     db.session.delete(query)
        #     db.session.commit()
        #     rates = RateDAO.update_rates(RateDAO.SYMBOLS)
        # else:
        #
        return rates

    def update_rates(self, symbols: list[str]):
        rates = {}
        for symbol in symbols:
            token_id = coingeko.search_token_id(symbol.upper())
            if not token_id:
                continue
            token_price = coingeko.get_price(token_id).get(token_id)
            if not token_price:
                continue
            rates[symbol.upper()] = token_price['usd'] if token_price.get('usd') else 0
        self.create_rates(rates=rates)
        return rates

    def create_rates(self, rates: dict) -> bool:
        r = [Rate(from_currency_symbol=symbol, rate=rate, to_currency_symbol='USD') for symbol, rate in rates.items()]
        self.session.add_all(r)
        self.session.commit()
        return True


rate_dao = RateDAO()
