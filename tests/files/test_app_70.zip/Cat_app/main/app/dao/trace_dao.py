import os
import stat
from copy import copy
from datetime import datetime
from uuid import UUID

from sqlalchemy.exc import IntegrityError

from app.dao.base_dao import BaseDAO
from app.models import FileMetadata
from app.models import Trace
from app.core import api_driver


class TraceDAO(BaseDAO):

    def __init__(self,
                 model,
                 default_sort_field: str = 'created_at',
                 default_sort_direction: str = 'desc'):
        super().__init__(model=model, default_sort_field=default_sort_field,
                         default_sort_direction=default_sort_direction)
        self.file_metadata_model = FileMetadata

    def get_selected(
            self,
            id: str = None,
            filter_spec: list[dict] = None,
            is_raiseable: bool = True,
            # should_terminate_session: bool = True
    ):

        trace = super().get_selected(id=id,
            filter_spec=filter_spec,
            is_raiseable=is_raiseable)

        # if not trace.is_internal:
        #
        #
        #     # data['trace_data']['trace_id'] = data['trace_data'].pop('id')
        #     if data.get('trace_data') and data['trace_data'].get("status"): trace.status = data['trace_data']["status"]

        return trace

    def create(self, **kwargs):
        metadata = None
        file_path = kwargs.pop('file_path') if kwargs.get('file_path') else None
        if file_path:
            stats = os.stat(file_path)
            _data = {
                "recent_access_at": datetime.fromtimestamp(stats.st_atime),
                "recent_modification_at": datetime.fromtimestamp(stats.st_mtime),
                "recent_metadata_modification_at": datetime.fromtimestamp(stats.st_mtime),
                "filemode": stat.S_IMODE(stats.st_mode),
                "size": stats.st_size,
                "filename": os.path.split(file_path)[1],
                "path": file_path,
            }

            metadata = FileMetadata(**_data)
            self.session.add(metadata)
            self.session.commit()

        _trace_data = {
            **kwargs,
            "file_metadata_id": metadata.file_metadata_id
        } if metadata else kwargs
        try:
            result = super().create(**_trace_data)
        except IntegrityError:
            self.session.rollback()
            return None
        return result

    def get_all_ids(self, case_id: UUID) -> list[UUID]:
        query = self.session.query(self.model.trace_id).filter(self.model.case_id == case_id).order_by(
            self.model.created_at.asc()).all()
        return [q.trace_id for q in query]


trace_dao = TraceDAO(model=Trace)
