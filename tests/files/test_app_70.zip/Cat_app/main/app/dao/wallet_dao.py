import logging

from sqlalchemy.exc import IntegrityError

from app.dao.base_dao import BaseDAO
from app.models import Wallet


class WalletDAO(BaseDAO):

    def create(self, **kwargs):
        try:
            result = super().create(**kwargs)
            logging.warning(f"Created new wallet: {result.wallet_id}")
        except IntegrityError as err:
            logging.error(f"Wallet creation IntegrityError: {err}")
            self.session.rollback()
            return None

        return result


wallet_dao = WalletDAO(model=Wallet)
