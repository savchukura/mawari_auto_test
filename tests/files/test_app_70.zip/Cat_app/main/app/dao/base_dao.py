import logging
from contextlib import contextmanager

import sqlalchemy_filters

from app import Session
from app import exceptions


@contextmanager
def session_scope() -> Session:
    """Provide a transactional scope around a series of operations."""
    session = Session()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


class BaseDAO:
    current_session: type(Session) | None

    def __init__(
            self,
            model,
            session: type(Session) = None,
            default_sort_field: str = 'created_at',
            default_sort_direction: str = 'desc'
    ):
        self.session = session if session else Session()
        self.model = model
        self.default_sort_field = default_sort_field
        self.default_sort_direction = default_sort_direction

    # @session_scope()
    def get_all(
            self,
            filter_spec: list,
            sort_spec: list,
            pagination_spec: tuple = None,
            should_terminate_session: bool = True
    ) -> (list, tuple):
        filter_spec.append({
            "model": self.model.__name__, "field": 'status',
            "op": "!=", "value": "deleted"
        })
        if not sort_spec:
            sort_spec = [{
                "model": self.model.__name__,
                "field": self.default_sort_field,
                "direction": self.default_sort_direction
            }]

        query = self.session.query(self.model)
        # logging.info(f"Queried all data len: {len(query.all())}")
        query = sqlalchemy_filters.apply_filters(
            query=query, filter_spec=filter_spec
        )
        query = sqlalchemy_filters.apply_sort(
            query=query, sort_spec=sort_spec,
        )
        # logging.warning(f"After sort and filter: {len(query.all())}")

        pagination = None
        if pagination_spec:
            query, pagination = sqlalchemy_filters.apply_pagination(
                query=query, page_number=pagination_spec[0], page_size=pagination_spec[1])

        return query, pagination

    def get_selected(
            self,
            id: str = None,
            filter_spec: list[dict] = None,
            is_raiseable: bool = True,
            # should_terminate_session: bool = True
    ):
        # if not self.current_session:
        #     self.current_session = self.session()

        if id:
            query = self.session.get(self.model, id)
        elif filter_spec:
            query = self.session.query(self.model)
            query = sqlalchemy_filters.apply_filters(
                query=query, filter_spec=filter_spec
            ).first()
        else:
            raise exceptions.BadAPIUsage

        if not query or hasattr(self.model, 'status') and query.status == 'deleted':
            if is_raiseable:
                raise exceptions.ContentNotFound

        # if should_terminate_session:
        #     self.current_session.close()
        #     self.current_session = None
        #     ...

        return query

    def create(self, **kwargs):

        intent = self.model(**kwargs)
        self.session.add(intent)
        self.session.commit()
        # self.current_session.close()
        # self.current_session = None
        return intent

    def update(self, id: str, new_data: dict, auto_commit: bool = True):
        intent = self.get_selected(id=id)
        for k, v in new_data.items():
            if hasattr(self.model, k) and v is not None:
                setattr(intent, k, v)

        if auto_commit:
            self.session.commit()
            # self.current_session.close()
            # self.current_session = None
        return intent

    def delete(self, id: str, auto_commit: bool = True):
        intent = self.get_selected(id=id)
        intent.status = 'deleted'
        if auto_commit:
            self.session.commit()
            # self.current_session.close()
            # self.current_session = None
        return True
