import logging

from sqlalchemy.exc import IntegrityError

from app.dao.base_dao import BaseDAO
from app.models import Asset


class AssetDAO(BaseDAO):

    def create(self, **kwargs):
        try:
            result = super().create(**kwargs)
            logging.warning(f"Created new asset: {result.asset_id}")
        except IntegrityError as err:
            logging.error(f"Asset creation IntegrityError: {err}")
            self.session.rollback()
            return None

        return result


asset_dao = AssetDAO(Asset)
