from app.dao.base_dao import BaseDAO
from app.models import Wallet

wallet_dao = BaseDAO(model=Wallet)
