from app.dao.base_dao import BaseDAO
from app.models import USBDevice

usb_devices_dao = BaseDAO(USBDevice)
