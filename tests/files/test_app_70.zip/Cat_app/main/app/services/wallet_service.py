import logging

from app.dao.rate_dao import rate_dao
from app.models import Wallet


def get_total_balance_from(wallets: list[Wallet]) -> float:
    total_usd = 0
    rates: dict = rate_dao.get_all()
    logging.debug(f"Rates: {rates}")

    for wallet in wallets:

        for asset in wallet.assets:
            rate = rates.get(asset.symbol, 0)
            usd_sum = rate * asset.amount
            total_usd += usd_sum
    return total_usd

