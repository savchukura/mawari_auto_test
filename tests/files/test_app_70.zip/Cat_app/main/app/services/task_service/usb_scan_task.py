import datetime as dt
import logging
import time

from prometheus_client import push_to_gateway

from app import usb_driver
from app.core import Session
from app.core import usb_scan_gauge, registry
from app.dao.case_dao import case_dao
from app.dao.trace_dao import trace_dao
from app.dao.usb_dao import usb_devices_dao
from app.services.log_service import async_benchmark
from utils import data_structures


@async_benchmark(event_name="usb_scan")
async def get_usb_traces(case_id: str, paths: list[str]):
    logging.info("USB scan] started")
    start_time = time.time()
    # case_dao.session = Session()
    usbs: list[data_structures.USB] = []
    for path in paths:
        usbs += usb_driver.extract_crypto_usb_from_windows_reg_file(path=path)
    # usbs = [ for path in paths]
    case = case_dao.get_selected(id=case_id)
    if not usbs:
        case.usb_scan_status = 'processed'
        case.updated_at = dt.datetime.now()
        case_dao.session.commit()
        return True

    trace_data = {
        "case_id": case_id,
        "trace_type": "usb_device",
        "source": "usb_scan",
        "content": "",
        "status": "new"
    }
    trace = trace_dao.create(**trace_data)

    for usb in usbs:
        usb_data = {
            "trace_id": trace.trace_id,
            "case_id": case_id,
            "pid": usb.pid,
            "vid": usb.vid,
            "vendor_name": usb.vendor_name,
            "description": usb.description,
            "attribution_url": "",
        }
        usb_devices_dao.create(**usb_data)

    case.usb_scan_status = 'processed'
    case.updated_at = dt.datetime.now()
    case_dao.session.commit()
    # case_dao.session.close()
    usb_scan_gauge.set(time.time() - start_time)
    push_to_gateway('dev.catlabs.zpoken.io:9091', job='usb_desktop_scan', registry=registry)
    logging.info("[USB scan] Completed")
    return True
