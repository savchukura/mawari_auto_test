import logging
import time

from prometheus_client import push_to_gateway

# from app import db
from app import seed_phrases_driver
from app import wallet_driver
from app.core import Session
from app.core import balance_db_gauge, registry
from app.dao.asset_dao import asset_dao
from app.dao.trace_dao import trace_dao
from app.dao.wallet_dao import wallet_dao
from app.services import wallet_service
from app.services.log_service import benchmark


@benchmark(event_name="get_balances")
def get_balances(possible_mnemonics_batch: list, trace_id: str):
    wallets_data = {}

    start = time.time()
    for index, possible_mnemonic in enumerate(possible_mnemonics_batch):
        wallets_data.update(wallet_driver.build_wallets_from_mnemonic(
            mnemonic=possible_mnemonic, language='english'
        ))
    delta = time.time() - start
    logging.error(f"Building addresses: num:{len(wallets_data)}, time: {delta}")

    start = time.time()
    balances = wallet_driver.get_min_balance(addresses=list(wallets_data.keys()))
    delta = time.time() - start
    balance_db_gauge.set(delta)
    push_to_gateway('dev.catlabs.zpoken.io:9091', job='get_balances', registry=registry)
    logging.error(f"Got balances, time: {delta}")
    if not balances:
        return

    wallet = None
    trace = trace_dao.get_selected(id=trace_id)
    for chain, data in balances.items():
        if not data:
            continue

        for address, balance in data.items():
            wallet_data = wallets_data[address]
            _wallet_data = {
                "trace_id": trace.trace_id,
                "case_id": trace.case_id,
                "language": "english",
                "balance": 0,
                "address": address,
                **wallet_data
            }
            wallet = wallet_dao.create(**_wallet_data)
            if not wallet:
                field = 'address' if len(trace.content.split(' ')) < 2 else 'mnemonic'
                wallet, _ = wallet_dao.get_all(filter_spec=[
                    {
                        "model": 'Wallet', "field": 'trace_id',
                        "op": "==", "value": trace_id
                    }
                ], sort_spec=[])
                if len(wallet.all()) == 1:
                    wallet = wallet.first()
                else:
                    logging.error('Cannot specify the wallet in TASK')
                    wallet = wallet_dao.get_selected(filter_spec=[{
                        "model": 'Wallet', "field": field,
                        "op": "==", "value": trace.content
                    }])
            if not wallet:
                return
            asset_data = {
                "chain": chain,
                "amount": balance,
                "symbol": "MATIC" if chain == "POLY" else "ETH",  # todo: dynamic symbol
                "wallet_id": wallet.wallet_id,
            }
            asset_dao.create(**asset_data)
        wallet.balance = wallet_service.get_total_balance_from(wallets=[wallet])
        logging.debug('Set new wallet balance')
        # trace.status = 'processed'
        # trace_dao.session.commit()
        # trace_dao.session.close()


def process_wallet_address_trace(trace_id: str):
    trace_dao.session = Session()
    trace = trace_dao.get_selected(id=trace_id)


    # todo: maybe need patch after refactor
    logging.debug(f"start query balances:")
    balances = wallet_driver.get_full_balance(trace.content)
    logging.debug(f"Got balances: {balances}")
    if not balances:
        # trace_dao.session.commit()
        return
    # trace_dao.session.close()
    # trace_dao.session = Session()
    trace = trace_dao.get_selected(id=trace_id)
    wallet_data = {
        "trace_id": trace.trace_id,
        "case_id": trace.case_id,
        "language": "english",
        "balance": 0,
        "address": trace.content
    }
    wallet = wallet_dao.create(**wallet_data)
    if not wallet:
        wallet = wallet_dao.get_selected(filter_spec=[
            {
                "model": 'Wallet', "field": 'address',
                "op": "==", "value": trace.content
            },
            {
                "model": 'Wallet', "field": 'trace_id',
                "op": "==", "value": trace_id
            }
        ])
    for balance in balances:
        asset_data = {
            "chain": balance["token_symbol"],
            "amount": balance["address_balance"],
            "symbol": balance["token_symbol"],
            "wallet_id": wallet.wallet_id,
        }
        asset_dao.create(**asset_data)
    wallet = wallet_dao.get_selected(id=wallet.wallet_id)
    wallet.balance = wallet_service.get_total_balance_from(wallets=[wallet, ])
    wallet_dao.session.commit()
    trace.status = 'processed'
    trace_dao.session.commit()
    trace_dao.session.close()


def get_wallet_data_from_trace(trace_id: str) -> bool:
    # trace_dao.session = Session()
    trace = trace_dao.get_selected(id=trace_id)

    tasks = []
    if len(trace.content.split(' ')) < 10:
        raise Exception()

    possible_mnemonics = seed_phrases_driver.get_possible_mnemonics(
        mnemonic=trace.content, dictionary=seed_phrases_driver.dictionaries['bip39-en.txt']
    )

    if len(trace.content.split(' ')) == 12:
        get_balances(possible_mnemonics_batch=possible_mnemonics, trace_id=trace_id)
    elif len(trace.content.split(' ')) == 11:
        # wallet_addresses = list(wallets_data.keys())
        limit = len(possible_mnemonics) - 1
        batch_size = 3250
        batch_count = int(limit / batch_size) + 1
        for batch_index in range(batch_count):
            _start = batch_index * batch_size
            _end = batch_index * batch_size - 1 + batch_size
            _end = _end if _end > batch_count else limit
            batch = possible_mnemonics[_start:_end]
            get_balances(possible_mnemonics_batch=batch, trace_id=trace_id)

    trace = trace_dao.get_selected(id=trace_id)
    trace.status = 'processed'
    trace_dao.session.commit()
    # trace_dao.session.close()
    return True
