import logging

import requests
# from app.models import Event
# from app import db
# from app import celery

WEBHOOK_URL = 'http://localhost:6010/api/v1/webhooks'
from uuid import UUID

class BaseTask(celery.Task):
    def __init__(self):
        super().__init__()

    # def __call__(self, *args, **kwargs):
    #     with db.session:
    #         return self.run(*args, **kwargs)

    def send_callback(
            self,
            case_id,
            scan_type
    ):
        call_back_payload = {
            "ok": True,
            "result": {
                "case_id": case_id,
                "scan_type": scan_type,
                "status": "processed"
            },
        }

        response = requests.post(
            url=f"{WEBHOOK_URL}/tasks",
            json=call_back_payload,
        )

        if response.status_code != 200:
            logging.warning(f"Callback returned error! Details:\n{response.content}")
        else:
            logging.info(f"Callback returned success! Details:\n{response.content}")

    def on_failure(self, exc, task_id, args, kwargs, einfo):
        logging.error(f"Balance updating event with task_id [{task_id}] failed.")

    def on_success(self, retval, task_id, args, kwargs):
        logging.info(f"Balance updating event with task_id [{task_id}] succeeded!")


class TraceTask(celery.Task):
    def __init__(self):
        # self.session = models.Session()
        super().__init__()

    # def __call__(self, *args, **kwargs):
    #     with self.session:
    #         return self.run(*args, **kwargs)

    def send_callback(
            self,
            trace_id
    ):
        call_back_payload = {
            "ok": True,
            "result": {
                "trace_id": trace_id,
                "scan_type": "image_scan",
                "status": "processed"
            },
        }

        response = requests.post(
            url=f"{WEBHOOK_URL}/traces",
            json=call_back_payload,
        )

        if response.status_code != 200:
            logging.warning(f"Callback returned error! Details:\n{response.content}")
        else:
            logging.info(f"Callback returned success! Details:\n{response.content}")

    def on_failure(self, exc, task_id, args, kwargs, einfo):
        logging.error(f"Balance updating event with task_id [{task_id}] failed.")

    def on_success(self, retval, task_id, args, kwargs):
        # self.send_callback()
        logging.info(f"Balance updating event with task_id [{task_id}] succeeded!")



# def process_images