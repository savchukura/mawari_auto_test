import datetime as dt
import logging
import time

from prometheus_client import push_to_gateway

from app import email_driver
from app import seed_phrases_driver
from app import wallet_driver
from app.core import Session
from app.core import registry
from app.dao.case_dao import case_dao
from app.dao.email_dao import email_dao
from app.dao.trace_dao import trace_dao
from app.services.log_service import async_benchmark
from utils import data_structures
from . import _helpers
from app.core import  browser_scan_gauge


@async_benchmark(event_name="email_scan")
async def get_email_traces(case_id: str, paths: list[str]):
    start_time = time.time()
    # case_dao.session = Session()
    logging.info("[Email scan] Started")
    content_types_payloads = {}
    domains = []
    for path in paths:
        mails = email_driver.get_email_traces(path=path)
        for msg in mails.mails:
            if msg.get('From') and msg.get('From') not in domains: domains.append(msg['From'])

            have_mnemonic_image = False
            have_mnemonic_text = False
            detected_wallets = None
            body = None

            payload = msg.get_payload()
            if isinstance(payload, list):

                for p in payload:
                    # h = p.get_headers()
                    _payload = p.get_payload()
                    content_type = p.get('Content-Type')
                    # if not content_types_payloads.get(content_type): content_types_payloads[content_type] = []
                    if 'image' in content_type:
                        pass
                        # if not content_types_payloads.get('image'): content_types_payloads['image'] = []
                        # try:
                        #     detected_text = seed_phrases_driver.detect_text(
                        #         image=base64.b64decode(_payload)
                        #     )
                        #     seed_phrases = seed_phrases_driver.detect_seed_phrase(
                        #         detected_text=detected_text
                        #     )
                        #
                        #     logging.debug("Completed seed_phrases extraction")
                        #
                        #     if seed_phrases:
                        #         filepath = os.path.join(os.getcwd(), 'tmp', str(case_id), f"email_{int(time.time())}.png")
                        #         image = Image.open(io.BytesIO((base64.b64decode(_payload))))
                        #         image.save(filepath)
                        #         _helpers.iterate_over_detected_seeds(
                        #             case_id=case_id, file_path=filepath, file_type="image",
                        #             seed_phrases=seed_phrases, scan_type='image_scan'
                        #         )
                        #         have_mnemonic_image = True
                        # except:
                        #     pass
                    elif 'plain' in content_type:
                        if not content_types_payloads.get('plain'): content_types_payloads['plain'] = []
                        if _payload and 'flowed' not in content_type:
                            detected_wallets = []
                            scan_type = 'email_scan'
                            wallets = wallet_driver.extract_wallet_addresses_from_str(_payload)
                            for chain, addresses in wallets.items():
                                detected_wallets += [data_structures.DetectedWallet(
                                    content=address, source=scan_type,
                                    chain=chain, symbol=chain
                                ) for address in list(set(addresses))]
                            detected_wallets = wallet_driver.false_positive_cleaning(detected_wallets=detected_wallets)
                            logging.debug(f"Detected_wallets: {detected_wallets}")
                            detected_text = _payload.split(' ')

                            seed_phrases = seed_phrases_driver.detect_seed_phrase(
                                detected_text=detected_text
                            )

                            logging.debug("Completed seed_phrases extraction")

                            _helpers.iterate_over_detected_seeds(
                                case_id=case_id,
                                seed_phrases=seed_phrases, scan_type=scan_type
                            )
                            if seed_phrases or detected_wallets:
                                body = _payload.replace('\r\n', '')
                                have_mnemonic_text = True
                    elif 'multipart' in content_type:
                        pass
                        # if not content_types_payloads.get('multipart'): content_types_payloads['multipart'] = []
                        # if _payload: content_types_payloads['multipart'].append(_payload)
                    elif 'html' in content_type:
                        if not content_types_payloads.get('html'): content_types_payloads['html'] = []
                        if _payload: content_types_payloads['html'].append(_payload)
                    elif 'message' in content_type:
                        if not content_types_payloads.get('message'): content_types_payloads['message'] = []
                        if _payload: content_types_payloads['message'].append(_payload)
                    elif 'pdf' in content_type:
                        continue
                    elif 'application' in content_type:
                        continue
                    else:
                        # if _payload:
                        if not content_types_payloads.get(content_type): content_types_payloads[content_type] = []
                        content_types_payloads[content_type].append(_payload)

                if have_mnemonic_text or have_mnemonic_image:
                    email_data = {
                        # "created_at": msg["Date"],
                        "sender": msg["From"],
                        "receiver": msg["Delivered-To"] or "",
                        "subject": msg["Subject"],
                        "body": body or ""
                    }
                    email = email_dao.create(**email_data)

                    logging.debug(f"Email created {email}")
                    if detected_wallets:
                        for wallet in detected_wallets:
                            logging.debug(f"Detected wallet: {wallet.content}")
                            trace_data = {
                                "case_id": case_id,
                                "email_id": email.email_id,
                                "trace_type": "wallet_address",
                                "content": wallet.content,
                                "source": wallet.source,
                                "status": "new"
                            }
                            trace = trace_dao.create(**trace_data)
                            if not trace:
                                continue


            elif isinstance(payload, str):
                if not content_types_payloads.get('str'): content_types_payloads['str'] = []
                content_types_payloads['str'].append(payload)
                # H = text/plain; charset="us-ascii"

    crypto_domains = "\n".join(domains)
    if crypto_domains: _helpers.create_trace_log(
        traces=crypto_domains, case_id=case_id,
        trace_type='email_domains', source='email_scan'
    )

    case = case_dao.get_selected(id=case_id)
    case.email_scan_status = 'processed'
    case.updated_at = dt.datetime.now()
    case_dao.session.commit()
    # return True
    logging.info("[Email scan] Completed")
    browser_scan_gauge.set(time.time() - start_time)
    push_to_gateway('dev.catlabs.zpoken.io:9091', job='email_desktop_scan', registry=registry)
    return True
