import datetime as dt
from uuid import UUID

# from app import db
from app.core import storage_service_driver
from app.dao.case_dao import case_dao
from app.dao.trace_dao import trace_dao
from utils import data_structures as ds


def create_trace_log(
        traces: str, case_id: str, trace_type: str, source: str
):
    # case_dao.session = Session()
    case = case_dao.get_selected(id=case_id)
    t_data = {
        "case_id": case_id,
        "trace_type": trace_type,
        "content": traces,
        "status": "new",
        "source": source
    }
    match source:
        case "image_scan":
            case.image_scan_status = "processed"
        case "browser_scan":
            case.browser_scan_status = "processed"
        case "email_scan":
            case.email_scan_status = "processed"
        case "application_scan":
            case.application_scan_status = "processed"
        case _:
            raise NotImplemented
    trace_dao.create(**t_data)
    return True


def iterate_over_detected_seeds(
        case_id: str,
        seed_phrases: list[ds.SeedPhrase],
        scan_type: str,
        file_path: str = None,
        file_type: str = None
):
    prev_seed, prev_dict = None, None
    for seed_phrase in seed_phrases:
        if prev_dict != seed_phrase.dictionary_name and prev_seed != seed_phrase.full_phrase:
            file_preview_url = storage_service_driver.upload_file(file_path=file_path) if file_path else None
            trace_dao.create(
                case_id=case_id, file_preview_url=file_preview_url, status='new', file_type=file_type,
                content=seed_phrase.full_phrase, source=scan_type, trace_type='mnemonic'
            )
        prev_dict = seed_phrase.dictionary_name
        prev_seed = seed_phrase.full_phrase


def finish_case_scan(case_id: UUID) -> bool:
    case = case_dao.get_selected(id=case_id)
    # full_seed_num = sum([1 for f in case.mnemonics if f.crypto_connection == 'full'])
    # potential_seed_num = len(case.mnemonics) - full_seed_num

    case.image_scan_status = 'processed'
    case.updated_at = dt.datetime.now()
    db.session.commit()
    return True
