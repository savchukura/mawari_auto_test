import datetime as dt
import logging
import os
import time

from prometheus_client import Gauge, push_to_gateway

from app import browser_driver
from app.core import Session
from app.dao.case_dao import case_dao
from app.services.log_service import async_benchmark
from resource_path import resource_path
from utils import filesystem_tools
from . import _helpers
from app.core import browser_scan_gauge
from app.core import registry


@async_benchmark(event_name="browser_scan")
async def get_browser_traces(case_id: str):

    start_time = time.time()
    logging.info("[Browser scan] Started")

    # paths = filesystem_tools.extract_paths_from_case_tmp_dir(case_id=case_id)
    response = browser_driver.get_crypto_traces(path=resource_path(os.path.join('tmp', case_id)))

    if not response:
        logging.info(f"Empty response for {case_id=} browser_scan")
        return False

    history_traces = "\n".join(response.history_domains)
    cookie_traces = "\n".join(response.cookie_domains)
    bookmark_traces = "\n".join(response.bookmark_domains)
    if history_traces: _helpers.create_trace_log(
        traces=history_traces, case_id=case_id,
        trace_type='history_domains', source='browser_scan'
    )
    if cookie_traces: _helpers.create_trace_log(
        traces=cookie_traces, case_id=case_id,
        trace_type='cookie_domains', source='browser_scan'
    )
    if bookmark_traces: _helpers.create_trace_log(
        traces=bookmark_traces, case_id=case_id,
        trace_type='bookmark_domains', source='browser_scan'
    )
    case_dao.session = Session()
    case = case_dao.get_selected(id=case_id)

    case.browser_scan_status = 'processed'
    case.updated_at = dt.datetime.now()
    case_dao.session.commit()
    # case = case_dao.get_selected(id=case_id)
    # case_dao.session.close()
    logging.debug(f'Browser scan status: {case.browser_scan_status}')
    # case_dao.session.close()
    logging.info(f"[Browser scan] Completed in {time.time() - start_time}")
    browser_scan_gauge.set(time.time() - start_time)
    push_to_gateway('dev.catlabs.zpoken.io:9091', job='browser_desktop_scan', registry=registry)
    logging.info("pushed metrics to gateway")
    return True
