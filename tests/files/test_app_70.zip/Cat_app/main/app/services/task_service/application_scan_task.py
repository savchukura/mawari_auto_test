import logging
import os.path
import time
from datetime import datetime

from prometheus_client import push_to_gateway

from app import application_driver
from app.core import Session
from app.core import application_scan_gauge, registry
from app.core import seed_phrases_driver
from app.dao.case_dao import case_dao
from app.services.log_service import async_benchmark
from config import resource_path
from . import _helpers


@async_benchmark(event_name="application_scan")
async def get_application_traces(case_id: str, paths: list[str]) -> str:
    # case_dao.session = Session()
    start_time = time.time()
    logging.info("[Application scan] Started")
    detected_str = application_driver.extract_apps_data(path=resource_path(os.path.join('tmp', case_id)))
    if not detected_str:
        logging.info(f"Empty text data for {case_id=} application_scan")

    detected_text = []
    detected_text += [d.split(' ') for d in detected_str]

    seed_phrases = seed_phrases_driver.detect_seed_phrase(
        detected_text=detected_text
    )
    _helpers.iterate_over_detected_seeds(
        case_id=case_id, seed_phrases=seed_phrases, scan_type='application_scan'
    )
    logging.debug("Completed seed_phrases extraction")
    app_paths = application_driver.get_crypto_traces(paths=paths)
    app_names = '\n'.join([os.path.split(path)[1] for path in app_paths])

    if app_names:
        _helpers.create_trace_log(
            traces=app_names, case_id=case_id,
            trace_type='applications', source='application_scan'
        )

    # text =
    case = case_dao.get_selected(id=case_id)
    case.application_scan_status = 'processed'
    case.updated_at = datetime.now()
    case_dao.session.commit()

    application_scan_gauge.set(time.time() - start_time)
    push_to_gateway('dev.catlabs.zpoken.io:9091', job='application_desktop_scan', registry=registry)

    logging.info("[Application scan] Completed")
    return app_names
