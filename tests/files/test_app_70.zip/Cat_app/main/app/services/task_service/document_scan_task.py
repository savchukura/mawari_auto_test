import datetime as dt
import logging
import os.path
import time

from prometheus_client import push_to_gateway

from app import wallet_driver
from app.core import Session
from app.core import document_scan_gauge, registry
# from app import db
from app.core import seed_phrases_driver
from app.dao.case_dao import case_dao
from app.dao.trace_dao import trace_dao
from app.services.log_service import async_benchmark
from static.muted_docnames import muted_docnames
from utils import data_structures
from utils import filesystem_tools
from . import _helpers


@async_benchmark(event_name="doc_scan")
async def get_document_traces(case_id: str, paths: list[str]):
    scan_type = 'doc_scan'
    start_time = time.time()
    # case_dao.session = Session()
    case = case_dao.get_selected(id=case_id)

    logging.debug(f"Got list of filepath with len {len(paths)}")
    detected_wallets: list[data_structures.DetectedWallet] = []
    # for path in paths:
    paths = [path for path in paths if __filename_check(os.path.split(path))]

    for path in paths:
        detected_wallets += wallet_driver.detect_wallets_in_file(
            path=path, scan_type=scan_type
        )
        detected_str = filesystem_tools.extract_text_from_file(path=path).split('\n')

        detected_text = []
        detected_text += [d.split(' ') for d in detected_str]

        seed_phrases = seed_phrases_driver.detect_seed_phrase(
            detected_text=detected_text
        )
        _helpers.iterate_over_detected_seeds(
            case_id=case_id, file_path=path, file_type="file",
            seed_phrases=seed_phrases, scan_type='doc_scan'
        )
    logging.debug("Completed wallet extraction")

    for wallet in detected_wallets:
        logging.debug(f"Detected wallet: {wallet.content}")
        trace_data = {
            "case_id": case_id,
            "trace_type": "wallet_address",
            "content": wallet.content,
            "source": wallet.source,
            "status": "new"
        }
        trace = trace_dao.create(**trace_data)
        if not trace:
            continue

    logging.debug("Started seed_phrases extraction")

    # logging.debug("Completed seed_phrases extraction")

    case.doc_scan_status = 'processed'
    case.updated_at = dt.datetime.now()
    case_dao.session.commit()
    document_scan_gauge.set(time.time() - start_time)
    push_to_gateway('dev.catlabs.zpoken.io:9091', job='doc_desktop_scan', registry=registry)
    # case_dao.session.close()
    return True


def __filename_check(filename) -> bool:
    for md in muted_docnames:
        if md in filename:
            return False
    return True
