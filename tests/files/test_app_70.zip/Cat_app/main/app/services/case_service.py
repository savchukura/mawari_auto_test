import datetime
import json
import logging
import os
import time
from uuid import UUID

from app import exceptions
from app.core import Session
from app.dao.case_dao import case_dao
from app.services import task_service
from config import Config
from utils import filesystem_tools


def get_all() -> (list, tuple):
    case_dao.session.expire_all()
    case_dao.session = Session()
    # filter_spec_options = {
    #     "full_scan_status": {"model": "Case", "field": "full_scan_status"},
    # }
    # filter_spec = url_parser.get_filters(
    #     url_args=url_args, filter_spec_options=filter_spec_options
    # )
    # # filter_spec += url_parser.get_datetime_period_filters()
    # pagination_spec = url_parser.get_pagination(url_args=url_args)

    filter_spec = []
    pagination_spec = (1, 10)

    cases, pagination = case_dao.get_all(filter_spec=filter_spec, sort_spec=[], pagination_spec=pagination_spec)
    response = [c.to_dict() for c in cases]
    case_dao.session.close()
    # case_dao.session = None
    # p.insert_pagination_info(response, pagination)
    return response, pagination


async def create_case(source: str | list, data: dict) -> dict:
    case_dao.session = Session()
    logging.info("Started creating")
    if not source:
        raise exceptions.BadAPIUsage("You must provide at least one file")
    if not data:
        raise exceptions.BadAPIUsage("You must provide data")

    if isinstance(source, str):
        filename_list = [source]
    elif isinstance(source, list) or isinstance(source, tuple):
        filename_list = source
    else:
        logging.warning(f"Source type: {type(source)}")
        raise NotImplemented

    processed_filename_list = await process_uploaded_files(filename_list)
    # processed_filename_list = [os.path.abspath(p) for p in processed_filename_list]
    case = case_dao.create(
        name=data['name'],
        filenames=processed_filename_list,
        executor_id='dade84b7-cf72-43b7-aa19-8cfeb81dbe70',
        spectator_id=None
    )
    directory = filesystem_tools.mkdir_safe(
        tmp_dirname=Config.TMP_DIRECTORY,
        dirname=str(case.case_id)
    )
    artifacts = {
        "paths": filename_list,
        "extracted_paths": []
    }
    # await filesystem_tools.unpack_zips(filenames=filename_list, directory=directory)

    artifacts_filename = os.path.join(directory, 'artifacts.json')
    with open(artifacts_filename, 'w') as artifacts_file:
        json.dump(artifacts, artifacts_file)

    case_dao.session.close()
    logging.info("Finished creating")
    return case.to_dict()


def get_selected(case_id: str) -> dict:
    case_dao.session = Session()
    case = case_dao.get_selected(id=case_id)

    result = {
        'executor_email': "ladygaga@gmail.com",
        'spectator_email': "britney@gmail.com",
        'applications_num': 0,
        'full_mnemonics_num': 0,
        'partially_mnemonics_num': 0,
        'domains_num': 0,
        'wallet_addresses_num': 0,
        'usb_devices_num': 0,
        'traces_num': len(case.traces) if case.traces else 0,
        'total_balance': round(sum(w.balance for w in case.wallets), 2)
    }
    for t in case.traces:
        match t.trace_type:
            case "mnemonic":
                words = len(t.content.split(' ')) if t.content else 0
                if words == 12:
                    result['full_mnemonics_num'] += 1
                else:
                    result['partially_mnemonics_num'] += 1
            case "wallet_address":
                result['wallet_addresses_num'] += 1
            case 'history_domains' | 'cookie_domains' | 'email_domains':
                result['domains_num'] += len(t.content.split('\n'))
            case 'applications':
                result['applications_num'] += len(t.content.split('\n'))
            case 'usb_device':
                result['usb_devices_num'] += 1
    case_dao.session.close()
    return {**case.to_dict(exclude_keys=('usb_devices', 'wallets', 'traces_num')), **result}


def delete_case(case_id: UUID) -> None:
    case_dao.delete(id=case_id)
    return


async def process_uploaded_files(filepaths: list, cfg: dict = None) -> list[str]:
    filename_list: list[str] = []
    for _filepath in filepaths:
        filename, extension = os.path.splitext(_filepath)
        if extension.lower() == '.zip':
            # filename_list.append(_filepath)
            filename_list += filesystem_tools.process_zip_file(
                _filepath, extract_all=False
            )
        elif extension.lower() == '.e01':
            filename_list.append(_filepath)
            # filename_list += filesystem_tools.process_e01_file(file, cfg=cfg)
        else:
            filename_list.append(_filepath)

    return filename_list


async def process_action(case_id: str, data: dict) -> dict:
    logging.debug(f'Scan starting. Creating session: {datetime.datetime.now()}')
    # logging.debug(f'Scan starting: {datetime.datetime.now()}')
    # case_dao.session = Session(expire_on_commit=True)
    # logging.warning("Processing")
    case = case_dao.get_selected(id=case_id)
    logging.debug(f'Got case from a db: {datetime.datetime.now()}')
    if case.full_scan_status != 'new':
        logging.debug(f'Case scan skipped: {case.full_scan_status}: {datetime.datetime.now()}')
        return {}
    artifacts_filepath = os.path.join(Config.TMP_DIRECTORY, case_id, 'artifacts.json')
    with open(artifacts_filepath, 'r') as file:
        file_data = json.load(file)

    filename_list = file_data.get('paths')
    # total_files_num = len(filename_list)
    logging.debug(f'Got filename list from case: {datetime.datetime.now()}')
    if not filename_list:
        logging.warning('There is no files to process')
        return {}

    if len(filename_list) == 1:
        if os.path.isdir(filename_list[0]):
            logging.debug(f'Started to process dir`s filepaths : {datetime.datetime.now()}')
            filename_list += filesystem_tools.get_all_filepaths(directory=filename_list[0])
        elif os.path.splitext(filename_list[0])[1] == '.zip':
            logging.debug(f'Started to process .zip file : {datetime.datetime.now()}')
            filesystem_tools.process_zip_file(zip_file=filename_list[0], extract_all=True,
                                              directory=os.path.join('tmp', case_id))

    filename_list += filesystem_tools.get_all_filepaths(directory=os.path.join('tmp', case_id))

    # filename_list += filesystem_tools.get_artifacts_filepaths(artifatcs=file_data)
    logging.debug(f'Init sorting by filetype: {datetime.datetime.now()}')

    sorted_filenames = await filesystem_tools.sort_filenames_by_extension(
        filename_list=filename_list
    )
    if not hasattr(case, '_sa_instance_state'):
        case = case_dao.get_selected(id=case_id)
    case.image_scan_status = 'processed'
    case.total_files_num = len(filename_list)
    case_dao.session.commit()
    # case_dao.session.close()
    logging.info("started")
    match data['action']:
        case 'start_light_scan':
            match case.doc_scan_status:
                case 'new' | 'failed':
                    if not hasattr(case, '_sa_instance_state'):
                        case = case_dao.get_selected(id=case_id)
                    case.doc_scan_status = 'processing'
                    case_dao.session.commit()
                    # case_dao.session.close()
                    await task_service.get_document_traces(
                        case_id=case_id, paths=sorted_filenames["docs"]
                    )
                case 'processing' | 'processed':
                    logging.debug(f'Doc scan has been skipped: {case.doc_scan_status=}')
            match case.usb_scan_status:
                case 'new' | 'failed':
                    if not hasattr(case, '_sa_instance_state'):
                        case = case_dao.get_selected(id=case_id)
                    case.usb_scan_status = 'processing'
                    case_dao.session.commit()
                    await task_service.get_usb_traces(
                        case_id=case_id, paths=sorted_filenames["registry"]
                    )
                case 'processing' | 'processed':
                    logging.debug(f'USB scan has been skipped: {case.usb_scan_status=}')
            match case.email_scan_status:
                case 'new' | 'failed':
                    if not hasattr(case, '_sa_instance_state'):
                        case = case_dao.get_selected(id=case_id)
                    case.email_scan_status = 'processing'
                    case_dao.session.commit()
                    await task_service.get_email_traces(
                        case_id=case_id, paths=sorted_filenames["emails"]
                    )
                case 'processing' | 'processed':
                    logging.debug(f'Email scan has been skipped: {case.email_scan_status=}')
            match case.browser_scan_status:
                case 'new' | 'failed':
                    if not hasattr(case, '_sa_instance_state'):
                        case = case_dao.get_selected(id=case_id)
                    case.browser_scan_status = 'processing'
                    case_dao.session.commit()
                    # case_dao.session.close()
                    logging.debug(f'BEFORE Browser scan status: {case.browser_scan_status}')
                    # case_dao.session.close()
                    await task_service.get_browser_traces(
                        case_id=case_id
                    )
                    logging.debug(f'AFTER Browser scan status: {case.browser_scan_status}')
                case 'processing' | 'processed':
                    logging.debug(f'Browser scan has been skipped: {case.browser_scan_status=}')
            match case.application_scan_status:
                case 'new' | 'failed':
                    if not hasattr(case, '_sa_instance_state'):
                        case = case_dao.get_selected(id=case_id)
                    case.application_scan_status = 'processing'
                    case_dao.session.commit()
                    await task_service.get_application_traces(
                        case_id=case_id, paths=sorted_filenames["apps"]
                    )
                case 'processing' | 'processed':
                    logging.debug(f'App scan has been skipped: {case.application_scan_status=}')
        case _:
            return {}
    case.total_files_num = len(filename_list)
    case_dao.session.commit()
    case_dao.session.close()



    logging.warning("finished")
    # case_dao.session.close()

