import logging
from copy import copy
from uuid import UUID

# from app import db
from app.dao.case_dao import case_dao
from app.dao.trace_dao import trace_dao
from app.core import api_driver
from app.core import Session
# from utils import api_tools
# from utils import pdf_driver
from app.services.task_service import trace_tasks

def get_all(case_id: str, url_args: dict):
    case_dao.session = Session()
    if url_args.get('source') == 'full_scan':
        url_args.pop('source', None)
    url_args['case_id'] = str(case_id)
    filter_spec_options = {
        "trace_type": {"model": "Trace", "field": "trace_type"},
        "source": {"model": "Trace", "field": "source"},
        "case_id": {"model": "Trace", "field": "case_id"},
    }
    # filter_spec = api_tools.url_parser.get_filters(
    #     url_args=url_args, filter_spec_options=filter_spec_options
    # )
    # filter_spec += url_parser.get_datetime_period_filters()
    # pagination_spec = api_tools.url_parser.get_pagination(url_args=url_args)
    case_dao.get_selected(id=case_id)
    traces, pagination = trace_dao.get_all()
    case_dao.session.close()
    result = [t.to_dict() for t in traces]
    # p.insert_pagination_info(result, pagination)
    return result, pagination


def get_selected(trace_id: UUID) -> dict:
    trace = trace_dao.get_selected(id=trace_id)

    action_data = {}
    if not trace.is_internal:
        data = api_driver.get_trace(trace_id=trace.trace_id)
        if not data:
            t = copy(trace)
            data = api_driver.send_trace(data=t.to_dict(exclude_keys=('is_internal', 'created_at')))
        return data
    match trace.trace_type:
        case 'wallet_address' | 'mnemonic':
            wallet_data = {}
            assets = []
            match trace.status:
                case 'processed':
                    if trace.wallets:

                        if trace.trace_type == 'wallet_address':
                            _wallet_data = {"address": trace.content}
                        else:
                            _wallet_data = {"mnemonic": trace.content}

                        wallet = trace.wallets[0]
                        assets = [a.to_dict() for a in wallet.assets]
                        wallet_data = {**wallet.to_dict(), "assets": assets}
                    else:
                        wallet_data = {"mnemonic": trace.content, "assets": assets}
                case 'new' | 'failed':
                    action_data = {"action": "Parse wallet"}
                    if trace.trace_type == 'wallet_address':
                        wallet_data = {"address": trace.content, "assets": assets}
                    else:
                        wallet_data = {"mnemonic": trace.content, "assets": assets}
                case 'processing':
                    if trace.trace_type == 'wallet_address':
                        wallet_data = {"address": trace.content, "assets": assets}
                    else:
                        wallet_data = {"mnemonic": trace.content, "assets": assets}

            # if assets: action_data = {"action": "Update balance"}
            data = {**wallet_data, **action_data}
        case 'usb_device':
            data = trace.usb_devices[0].to_dict() if trace.usb_devices else {}
        case 'history_domains' | 'cookie_domains' | 'email_domains':
            data = {}
        case 'applications':
            data = {}
        case _:
            raise ValueError('Unsupported `trace_type`')

    res = {"case_name": trace.case.name, **trace.to_dict(), **data}
    # case_dao.session.close()
    return res


def get_all_by_type(case_id: str):
    data, _ = trace_dao.get_all(filter_spec=[{
        "model": 'Trace', "field": 'case_id',
        "op": "==", "value": case_id
    }], sort_spec=[])

    data = data.all()

    res = {
        "image_scan": [],
        "browser_scan": [],
        "doc_scan": [],
        "email_scan": [],
        "usb_scan": [],
        "application_scan": [],
    }
    for d in data:
        res[d.source].append(d.to_dict())
    return res


async def process_trace(case_id: str, trace_id: str):
    trace_dao.session = Session()
    trace = trace_dao.get_selected(id=trace_id)

    if trace.status not in ('new', 'failed'):
        return
    trace.status = 'processing'
    trace_dao.session.commit()
    # logging.debug("COMMIT")
    # trace_dao.session.close()
    try:
        match trace.trace_type:
            case 'mnemonic':
                logging.debug('mnemonic trace procces has started')
                if len(trace.content.split(' ')) < 12:
                    trace.is_internal = False
                    trace_dao.session.commit()
                    trace = trace_dao.get_selected(trace_id)
                    trace_id = api_driver.send_trace(data=trace.to_dict(exclude_keys=('is_internal', 'created_at')))
                else:
                    trace_tasks.get_wallet_data_from_trace(trace_id=trace_id)
            case 'wallet_address':
                logging.debug('wallet trace procces has started')
                trace_tasks.process_wallet_address_trace(trace_id=trace_id)
            case _:
                raise ValueError(f'Unsupported {trace.trace_type=}')
    except Exception as err:
        logging.error(err)
        # trace_dao.session = Session()
        trace = trace_dao.get_selected(id=trace_id)
        trace.status = 'failed'
        trace_dao.session.commit()
        trace_dao.session.close()
        return
    trace_dao.session.close()
    trace_dao.session = Session()
    trace = trace_dao.get_selected(trace_id)
    if not hasattr(trace, '_sa_instance_state'):
        trace = trace_dao.get_selected(id=trace_id)
    trace.status = 'processed'
    trace_dao.session.close()

    return {"status": "processing"}


def process_webhook(data: dict):
    if not data.get('ok'):
        logging.warning('Got not ok scan response')
        return
    # res = data['result']
    # scan_type = data['scan_type']

    logging.info(f'Got wh payload: {data}')

    return "OK"


def trace_to_pdf(case_id: UUID, trace_id: UUID):
    result = get_selected_trace(case_id=case_id, trace_id=trace_id)
    pdf_driver.create_from_dict(data=result)
    return send_file('../report.pdf')
