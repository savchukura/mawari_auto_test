import logging
import time
import tracemalloc

from app.dao.log_dao import log_dao
import functools


def async_benchmark(original_function=None, event_name: str = None):

    def _decorate(function):

        @functools.wraps(function)
        async def wrapped_function(*args, **kwargs):
            start_time = time.time()
            tracemalloc.start()
            await function(*args, **kwargs)

            spent_time = time.time() - start_time
            logging.info(f"Spent time: {spent_time}")
            mem_pressure = tracemalloc.get_traced_memory()
            data = {
                "memory_pressure_bytes": mem_pressure[0],
                "time_spent_seconds": spent_time,
                "event_name": event_name,
                "case_id": kwargs.get('case_id')
            }
            log_dao.create(**data)
            tracemalloc.stop()

        return wrapped_function

    if original_function:
        return _decorate(original_function)

    return _decorate


def benchmark(original_function=None, event_name: str = None):

    def _decorate(function):

        @functools.wraps(function)
        def wrapped_function(*args, **kwargs):
            start_time = time.time()
            tracemalloc.start()
            function(*args, **kwargs)

            spent_time = time.time() - start_time
            logging.info(f"Spent time: {spent_time}")
            mem_pressure = tracemalloc.get_traced_memory()
            data = {
                "memory_pressure_bytes": mem_pressure[0],
                "time_spent_seconds": spent_time,
                "event_name": event_name,
                "case_id": kwargs.get('case_id')
            }
            log_dao.create(**data)
            tracemalloc.stop()

        return wrapped_function

    if original_function:
        return _decorate(original_function)

    return _decorate
# def build_log():
#     data = {
#
#     }
#     log_dao.create(**data)