from kivy.properties import StringProperty
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.recycleview import RecycleView


class TraceMiniCard(ButtonBehavior, BoxLayout):
    trace_type = StringProperty()
    content = StringProperty()
    trace_names = {
        "history_domains": "History Domains",
        "cookie_domains": "Cookie Domains",
        "email_domains": "Email Domains",
        "mnemonic": "Seed Phrase",
        "wallet_address": "Wallet",
        "applications": "Applications",
        "usb_device": "USB device",
    }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        # self.content = self.content.replace('\n', ' | ')

    def on_click(self, *args):
        manager = self.parent.parent.parent.parent.parent.parent.manager
        screen = manager.get_screen('selected_trace_view')
        screen.refresh(trace_id=self.id)
        manager.current = 'selected_trace_view'
        manager.transition.direction = "left"


class AllTracesLayout(RecycleView):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # self.data = data
