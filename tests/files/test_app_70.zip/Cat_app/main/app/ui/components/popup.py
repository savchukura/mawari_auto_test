from kivy.uix.popup import Popup


class InfoPopup(Popup):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.title = "Info"