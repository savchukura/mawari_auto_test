import datetime
import logging
import threading

from kivy.metrics import dp
from kivy.properties import ObjectProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label
from kivy.uix.recycleview.views import RecycleDataViewBehavior
from kivy.uix.widget import Widget

from app.core import loop
from app.services import case_service
# from app.core import pool
from app.ui.components.popup import InfoPopup
from app.ui.utils import OutlineCaseCardButton, FilledCaseCardButton


class CaseCardInner(FloatLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)




class CaseCardAttribute:
    def __init__(self, name, id, traces_num, total_files_num, created_at, full_scan_status, **kwargs):
        self.name = name
        self.id = id
        self.traces_num = traces_num
        self.total_files_num = total_files_num
        self.created_at = created_at
        self.full_scan_status = full_scan_status


class CaseCardComponent(RecycleDataViewBehavior, BoxLayout):
    index = None
    attribute = ObjectProperty()
    full_scan_status: str | None
    is_started_now: bool

    def __init__(self, **kwargs):
        super(CaseCardComponent, self).__init__(**kwargs)
        self.full_scan_status = None
        self.is_started_now = False
        # Clock.schedule_once(self.finish_init, 0)

    def refresh_view_attrs(self, rv, index, data):
        ''' Catch and handle the view changes '''
        self.index = index
        print("refresh")
        self.create_widgets(rv, data)
        return super(CaseCardComponent, self).refresh_view_attrs(
            rv, index, data)

    def create_widgets(self, rv, value: dict):
        # rv = App.get_running_app().root

        rv.cache_widgets(self.children)
        self.clear_widgets()
        # label = rv.get_name()
        # label.text = value['name']
        # self.add_widget(label)

        self._build_interface(value)

    def on_open_click(self, *args):
        logging.debug('Open click')
        manager = self.parent.parent.parent.parent.parent.manager
        screen = manager.get_screen('selected_case_view')
        screen.refresh(case_id=self.id)
        manager.current = 'selected_case_view'
        manager.transition.direction = "left"

    def _target(self):

        logging.debug(f'Scan starting: {datetime.datetime.now()}')
        data = {"action": "start_light_scan"}
        # multiprocessing.Process(target=lambda: case_service.process_action(case_id=self.id, data=data))
        loop.run_until_complete(case_service.process_action(case_id=self.id, data=data))

    def on_start_click(self, *args):

        logging.debug('Start click')
        # case_dao.session = Session()
        # case = case_service.get_selected(self.id)
        logging.debug('Queried case')
        if self.full_scan_status != 'new':
            logging.debug(f'Case scan skipped: {self.full_scan_status=}: {datetime.datetime.now()}')
            popup = InfoPopup(size_hint=(None, None), size=(dp(450), dp(200)))
            popup_text = Label()
            match self.full_scan_status:
                case 'processing':
                    popup_text.text = "This case has been already in processing"
                case 'processed':
                    popup_text.text = "This case has been already processed"
            popup.content = popup_text
            popup.open()
            return
        else:
            logging.debug(f'Case scan: {self.full_scan_status=}')
        self.start_button.disabled = True
        self.status_label.text = 'Processing'
        logging.debug(f'Clicked: {datetime.datetime.now()}')
        # self._target()
        threading.Thread(target=self._target).start()

    def _build_interface(self, data):
        case_inner_component_bl = BoxLayout()

        case_inner_component_bl.orientation = 'horizontal'
        case_inner_component_bl.height = dp(25)
        case_inner_component_bl.spacing = dp(10)
        # case_inner_component_bl.padding = dp(20)
        case_inner_component_bl.size_hint = 1, None
        case_inner_component_bl.pos_hint = {"center_x": .5, "center_y": .5}

        if data['full_scan_status'] in ('processed',):
            not_new_bl = BoxLayout()
            #
            l_bl = BoxLayout()
            files_label = Label()
            files_label.text = "Files: "
            files_label.bold = True
            l_bl.add_widget(files_label)
            files_num_label = Label()
            files_num_label.text = str(data['total_files_num'])
            l_bl.add_widget(files_num_label)
            r_bl = BoxLayout()
            traces_label = Label()
            traces_label.text = "Traces: "
            traces_label.bold = True
            traces_num_label = Label()
            traces_num_label.text = str(data['traces_num'])
            r_bl.add_widget(traces_label)
            r_bl.add_widget(traces_num_label)

            not_new_bl.add_widget(l_bl)
            not_new_bl.add_widget(r_bl)
            case_inner_component_bl.add_widget(not_new_bl)
        elif data['full_scan_status'] in ('processing', 'new'):
            label = "Processing" if data['full_scan_status'] == 'processing' else 'New case'
            status_label = Label()
            self.status_label = status_label
            status_label.text = label
            status_label.bold = True
            case_inner_component_bl.add_widget(status_label)

        case_card_inner = CaseCardInner()
        # case_card_inner.pa
        case_card_inner.add_widget(case_inner_component_bl)

        # ----------------------------
        name_layout = BoxLayout()

        name_layout.padding = dp(20)
        name_layout.size_hint = .88, None
        name_layout.height = dp(80)
        # name_layout.pos_hint = {"x": 0, "top": .5}

        name_label = Label()
        name_label.font_size = "19sp"
        name_label.bold = True
        # name_label.pos_hint = {"x": 0, "y": .5}
        name_label.size_hint = None, None
        name_label.size = name_label.texture_size
        name_label.text = data['name']
        name_layout.add_widget(name_label)
        span_widget = Widget()
        span_widget.size_hint = .6, 1
        name_layout.add_widget(span_widget)

        date_label = Label()
        date_label.font_size = "11sp"
        date_label.bold = True
        # date_label.pos[0] += dp(100)
        # date_label.padding = dp(21)
        date_label.size_hint = None, None
        date_label.size = date_label.texture_size
        date_label.text = datetime.datetime.strftime(data['updated_at'], "%Y-%m-%d %H:%M")
        date_label.opacity = .4
        name_layout.add_widget(date_label)

        # ---------------- BUTTONS ------------

        buttons_bl = BoxLayout()
        buttons_bl.orientation = "horizontal"
        buttons_bl.spacing = dp(10)
        buttons_bl.size_hint = 1, None
        buttons_bl.height = dp(50)
        open_button = OutlineCaseCardButton()
        open_button.background_color = (0, 0, 0, 0)
        open_button.text = 'Open'

        open_button.on_release = self.on_open_click

        start_button = FilledCaseCardButton()
        start_button.background_color = (0, 0, 0, 0)
        start_button.text = 'Start'
        start_button.on_release = self.on_start_click
        self.start_button = start_button

        buttons_bl.add_widget(open_button)
        buttons_bl.add_widget(start_button)

        gen_bl = BoxLayout()
        # gen_bl.size_hint = 1, None

        # gen_bl.padding = dp(20)
        gen_bl.spacing = dp(10)
        gen_bl.orientation = "vertical"
        gen_bl.add_widget(name_layout)
        gen_bl.add_widget(case_card_inner)
        gen_bl.add_widget(buttons_bl)
        self.add_widget(gen_bl)
        self.padding = dp(20)
