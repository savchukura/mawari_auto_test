import logging

from kivy.uix.boxlayout import BoxLayout


class USBTraceContent(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def refresh(self, trace_data: dict):
        if trace_data['trace_type'] != 'usb_device':
            logging.debug(f"{trace_data['trace_type']=}")
            raise Exception('Wrong `trace_type` for USBTraceContent')

        self.ids.vid_label.text = trace_data["vid"] if trace_data.get("vid") else ""
        self.ids.pid_label.text = trace_data["pid"] if trace_data.get("pid") else ""
        self.ids.vendor_name_label.text = trace_data["vendor_name"] if trace_data.get("vendor_name") else ""
        self.ids.description_label.text = trace_data["description"] if trace_data.get("description") else ""
        # self.ids.domains_view.data = [{"text": d} for d i