import datetime

from kivy.properties import StringProperty
from kivy.uix.boxlayout import BoxLayout

from app.ui.utils import ScanStatus


class CaseDetailsDropdown(BoxLayout):
    pass


class DetailedCaseCardComponent(BoxLayout):
    name = StringProperty()
    statuses_widget = None

    created_at = StringProperty()

    def refresh(self, case_data: dict, trace_data: dict):
        # print(case_data.keys())
        # 'usb_scan_status', 'application_scan_status', 'system_hash', 'created_at', 'total_files_num', 'potential_seed_phrases', 'updated_at', 'full_seed_phrases', 'name', 'image_scan_status', 'is_processed', 'browser_scan_status', 'spectator_id', 'email_scan_status', 'executor_id', 'doc_scan_status', 'traces', 'id', 'full_scan_status', 'executor_email', 'spectator_email', 'applications_num', 'full_mnemonics_num', 'partially_mnemonics_num', 'domains_num', 'wallet_addresses_num', 'usb_devices_num', 'traces_num', 'total_balance'

        self.ids.name.text = case_data.get("name")
        self.ids.total_files_num.text = str(case_data.get("total_files_num"))
        self.ids.full_mnemonics_num.text = str(case_data.get("full_mnemonics_num"))
        self.ids.applications_num.text = str(case_data.get("applications_num"))
        self.ids.domains_num.text = str(case_data.get("domains_num"))
        self.ids.wallet_addresses_num.text = str(case_data.get("wallet_addresses_num"))
        self.ids.usb_devices_num.text = str(case_data.get("usb_devices_num"))
        self.ids.traces_num.text = str(case_data.get("traces_num"))
        self.ids.total_balance.text = str(case_data.get("total_balance"))
        self.ids.created_at.text = datetime.datetime.strftime(case_data['created_at'], "%Y-%m-%d %H:%M:%S")
        self.ids.created_at_label.text = str(case_data.get("created_at"))
        self.ids.updated_at.text = datetime.datetime.strftime(case_data['updated_at'], "%Y-%m-%d %H:%M:%S")

        # self.ids.image_traces.data = trace_data["image_scan"]

        self.ids.browser_traces.data = trace_data["browser_scan"]
        self.ids.email_traces.data = trace_data["email_scan"]
        self.ids.document_traces.data = trace_data["doc_scan"]
        self.ids.usb_traces.data = trace_data["usb_scan"]
        self.ids.application_traces.data = trace_data["application_scan"]
        self._build_status_container(case_data=case_data)

    def _build_status_container(self, case_data: dict):
        self.ids.statuses_container.clear_widgets()
        scan_types_and_names = {
            # "image_scan_status": "Image scan",
            "browser_scan_status": "Browser scan",
            "email_scan_status": "Email scan",
            "doc_scan_status": "Document scan",
            "usb_scan_status": "USB scan",
            "application_scan_status": "Application scan",
        }
        for scan_type, scan_name in scan_types_and_names.items():
            status_label = ScanStatus()
            status_label.status = case_data[scan_type]
            status_label.ids.name.text = scan_name
            self.ids.statuses_container.add_widget(status_label)
