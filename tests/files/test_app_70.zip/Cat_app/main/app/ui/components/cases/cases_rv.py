from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.recycleview import RecycleView

# from app.components.utils import Clea
from app.services import case_service


class CaseCardsRecycleView(RecycleView):
    def __init__(self, **kwargs):
        case_data, _ = case_service.get_all()
        super().__init__(**kwargs)
        self.name_cache = []
        self.buttons_cache = []
        self.data = case_data

    def get_button(self):
        if len(self.buttons_cache) > 0:
            return self.buttons_cache.pop()
        else:
            return Button()

    def get_name(self):
        if len(self.name_cache) > 0:
            return self.name_cache.pop()
        else:
            return Label(bold=True)

    def cache_widgets(self, widgets):
        ...
        # print(f'--- {self}')
        # for index, w in enumerate(widgets):
        #     print(index, w)
            # if isinstance(w, Button):
            #     self.buttons_cache.append(w)
            # else:
            #     self.name_cache.append(w)
