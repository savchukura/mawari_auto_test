from kivy.uix.boxlayout import BoxLayout

from app.ui.components.traces import DomainsTraceContent
from app.ui.components.traces import MnemonicTraceContent
from app.ui.components.traces import USBTraceContent
from app.ui.components.traces import WalletAddressTraceContent


class DetailedTraceCard(BoxLayout):
    trace_id: str
    case_id: str
    content = None

    # detailed_trace_object = ObjectPrope/rty(None)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def refresh(self, trace_data: dict):
        self.trace_id = trace_data["id"]
        self.case_id = trace_data["case_id"]
        match trace_data['trace_type']:
            case 'mnemonic':
                content = MnemonicTraceContent()
            case 'wallet_address':
                content = WalletAddressTraceContent()
            case 'usb_device':
                content = USBTraceContent()
            case 'history_domains' | 'email_domains' | 'cookie_domains' | 'applications':
                content = DomainsTraceContent()
            case _:
                raise Exception(f"Unsupported trace_type: {trace_data['trace_type']}")
        content.refresh(trace_data)
        if self.content:
            self.ids.detailed_trace_object.remove_widget(self.content)
            self.content = None
        self.content = content
        self.ids.detailed_trace_object.add_widget(content)
        pass

    def back_button_clicked(self):
        manager = self.parent.manager
        screen = manager.get_screen('selected_case_view')
        screen.refresh(case_id=self.case_id)
        manager.current = 'selected_case_view'
        manager.transition.direction = "right"

    def fetch_updates_button_clicked(self):
        selected_trace_view = self.parent
        selected_trace_view.refresh(trace_id=self.trace_id)


