import asyncio
import logging
import threading

from kivy.uix.boxlayout import BoxLayout

from app.ui import utils
from app.core import loop
from app.services import trace_service


class MnemonicTraceContent(BoxLayout):
    status = None
    trace_id = None

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def refresh(self, trace_data: dict):
        if trace_data['trace_type'] != 'mnemonic':
            logging.debug(f"{trace_data['trace_type']=}")
            raise Exception('Wrong `trace_type` for MnemonicTraceContent')

        self.trace_id = trace_data["id"]
        if trace_data.get("mnemonic"):self.ids.mnemonic.text = trace_data["mnemonic"]

        if trace_data.get("address"):
            self.ids.address.text = trace_data["address"]
            self.ids.address_box.opacity = 1
        else:
            self.ids.address_box.opacity = 0

        if trace_data.get("public_key"):
            self.ids.public_key.text = trace_data["public_key"]
            self.ids.public_key_box.opacity = 1
        else:
            self.ids.public_key_box.opacity = 0

        if trace_data.get("private_key"):
            self.ids.private_key.text = trace_data["private_key"]
            self.ids.private_key_box.opacity = 1
        else:
            self.ids.private_key_box.opacity = 0

        if trace_data.get("balance"):
            self.ids.balance_box.opacity = 1
            self.ids.balance.text = trace_data["balance"]
        else:
            self.ids.balance_box.opacity = 0

        if trace_data.get('assets'):
            self.ids.assets_box.opacity = 1
            self.ids.assets_rv.data = [{"text": f"{a['symbol']} {a['amount']}"} for a in trace_data['assets']]
        else:
            self.ids.assets_box.opacity = 0

        self.ids.status.status = trace_data['status']
        self.ids.status.ids.name.bold = True
        self.ids.status.ids.name.text = f"Seed Phrase | {utils.trace_source_name_keys[trace_data['source']]}"
        # self.ids.domains_view.data = [{"text": d} for d in domains]

    # def _target(self):
    #     loop.run_until_complete()

    def parse_mnemonic(self):
        # if self.ids.status.status
        logging.info('clicked')
        asyncio.create_task(trace_service.process_trace(case_id="", trace_id=self.trace_id))

