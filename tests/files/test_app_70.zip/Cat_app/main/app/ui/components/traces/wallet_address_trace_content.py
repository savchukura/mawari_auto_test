import logging
import threading

from kivy.metrics import dp
from kivy.properties import StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label

from app.core import loop
from app.services import trace_service
from app.ui.components.popup import InfoPopup
from app.ui.utils import trace_source_name_keys


class WalletAddressTraceContent(BoxLayout):
    source = StringProperty()

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def refresh(self, trace_data: dict):
        if trace_data['trace_type'] != 'wallet_address':
            logging.debug(f"{trace_data['trace_type']=}")
            raise Exception('Wrong `trace_type` for WalletAddressTraceContent')

        self.trace_id = trace_data["id"]
        self.status = trace_data['status']
        self.ids.status_header.status = self.status
        self.ids.status_header.ids.name.text = f'Wallet Address | {trace_source_name_keys[trace_data["source"]]}'
        self.ids.status_header.ids.name.bold = True
        self.ids.address.text = trace_data["address"] if trace_data.get("address") else trace_data.get("content")
        if trace_data.get("balance"):
            self.ids.balance_box.opacity = 1
            self.ids.balance.text = trace_data["balance"]
        else:
            self.ids.balance_box.opacity = 0

        if trace_data.get('assets'):
            self.ids.assets_box.opacity = 1
            self.ids.assets_rv.data = [{"text": f"{a['symbol']} {a['amount']}"} for a in trace_data['assets']]
        else:
            self.ids.assets_box.opacity = 0

    def _target(self):
        loop.run_until_complete(trace_service.process_trace(case_id="", trace_id=self.trace_id))

    def parse_mnemonic(self):
        logging.info('clicked')
        logging.debug(f"{self.status=}")
        # detailed_trace_card = self.parent.parent.parent
        # detailed_trace_card.fetch_updates_button_clicked()
        # data = trace_service.get_selected(self.trace_id)
        # self.status = data['status']
        if self.status in ('processing', 'processed'):
            logging.debug(f'Trace scan skipped')
            popup = InfoPopup(size_hint=(None, None), size=(dp(400), dp(200)))
            popup_text = Label()
            popup_text.text = "This trace has been already in processing"
            popup.content = popup_text

            popup.open()

            return
        self.status = 'processing'
        threading.Thread(target=self._target, daemon=True).start()

    # def get_balances_clicked(self):
