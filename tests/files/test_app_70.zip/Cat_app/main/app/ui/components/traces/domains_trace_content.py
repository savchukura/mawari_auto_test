import logging

from kivy.uix.boxlayout import BoxLayout

from app.ui import utils


class DomainsTraceContent(BoxLayout):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def refresh(self, trace_data: dict):
        if trace_data['trace_type'] not in ('email_domains', 'cookie_domains', 'history_domains', 'applications'):
            logging.debug(f"{trace_data['trace_type']=}")
            raise Exception('Wrong `trace_type` for DomainsTraceContent')
        domains = trace_data["content"].split('\n')

        self.ids.header.text = utils.trace_type_name_keys[trace_data['trace_type']]
        self.ids.domains_view.data = [{"text": d} for d in domains]
