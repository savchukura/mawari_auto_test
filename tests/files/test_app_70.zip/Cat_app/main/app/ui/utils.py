import logging

from kivy.properties import ListProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button

trace_source_name_keys = {
    'email_scan': 'Email Scan',
    'doc_scan': 'Document Scan',
    'browser_scan': 'Browser Scan',
    'usb_scan': 'USB Scan',
    'application_scan': 'Application Scan'
}

trace_type_name_keys = {
    'email_domains': 'Email domains',
    'history_domains': 'History domains',
    'cookie_domains': 'Cookie domains',
    'applications': 'Applications',
    # 'application_scan': 'Application Scan'
}


class Colors:
    SUCCESS_COLOR = (0, 1, 0, 1)
    PROCESSING_COLOR = (1, 1, 0, 1)
    FAILED_COLOR = [1, 0, 0, 1]
    GREY_COLOR = (1, 1, 1, .5)


class ScanStatus(BoxLayout):
    col = ListProperty(Colors.GREY_COLOR)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def update_color(self):
        match self.status:
            case 'processing':
                col = Colors.PROCESSING_COLOR
            case 'processed':
                col = Colors.SUCCESS_COLOR
            case 'failed':
                col = Colors.FAILED_COLOR
            case 'new':
                col = Colors.GREY_COLOR
            case _:
                logging.warning(f'Unexpected status: {self.status=}')
                col = Colors.GREY_COLOR
        self.col = col


class FilledCaseCardButton(Button):
    pass


class OutlineCaseCardButton(Button):
    pass

from kivy.properties import ListProperty
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.label import Label


class CButton(ButtonBehavior, Label):
    removedChildren = ListProperty([])

    def exp_or_collapse(self, id, wrapper):
        # logging.info("EXP OF ")

        if len(self.removedChildren) > 0:
            # expand:
            # re-add all children
            self.removedChildren.reverse()
            wrapper.size_hint = 1, 1

            for child in self.removedChildren:
                id.add_widget(child)
            self.removedChildren = []
        else:
            # collapse
            # remove all children (except ourself)
            for child in id.children:
                if child != self:
                    self.removedChildren.append(child)
            for child in self.removedChildren:
                id.remove_widget(child)
            wrapper.size_hint = 1, None
            wrapper.height = 170
