from kivy.uix.screenmanager import Screen
from app.services import case_service
from app.services import trace_service


class SelectedCaseView(Screen):
    case_id = ''

    def refresh(self, case_id=None):
        self.case_id = case_id
        view = self.ids.detailed_case_card_component
        case_data, trace_data = self.fetch_data(case_id)
        view.refresh(case_data=case_data, trace_data=trace_data)
        # detailed_case_card_comp =

    def fetch_data(self, case_id):
        return case_service.get_selected(case_id=case_id), trace_service.get_all_by_type(case_id=case_id)
