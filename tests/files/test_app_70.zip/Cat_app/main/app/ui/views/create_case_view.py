import logging

from tkinter import filedialog

from kivy.clock import Clock
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.screenmanager import Screen
from app.core import loop
from app.services import case_service

import asyncio
class CreateCaseView(Screen):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)


class CreateCaseCardComponent(BoxLayout):

    def __init__(self, **kwargs):
        super(CreateCaseCardComponent, self).__init__(**kwargs)

    @staticmethod
    def get_path():
        import tkinter as tk
        root = tk.Tk()
        root.withdraw()
        return filedialog.askopenfilenames()

    def on_click(self):
        path = self.get_path()
        name = self.ids.case_name_text_input.text
        if not name or not path:
            return

            # show popup
        logging.warning(f"PATH of case {path}")
        asyncio.create_task(case_service.create_case(source=path, data={'name': name}))
        manager = self.parent.parent.manager
        screen = manager.get_screen('all_cases_view')
        Clock.schedule_once(lambda _: screen.fetch_data(), 1)
        self.clicked_back_to_menu()

    def clicked_back_to_menu(self):
        manager = self.parent.parent.manager
        manager.current = 'all_cases_view'
        manager.transition.direction = "left"

