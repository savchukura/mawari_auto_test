import logging

from kivy.uix.screenmanager import Screen
from app.dao.trace_dao import trace_dao
from app.core import Session
from app.services import trace_service


class SelectedTraceView(Screen):
    trace_id = ''

    def refresh(self, trace_id: str):
        self.trace_id = trace_id
        view = self.ids.detailed_trace_card
        logging.debug(f'Refreshing SelectedTraceView for {self.trace_id=}')
        trace_data = self.fetch_data(self.trace_id)
        view.refresh(trace_data=trace_data)
        # detailed_case_card_comp =

    def fetch_data(self, trace_id):
        trace_dao.session = Session()
        res =  trace_service.get_selected(trace_id=trace_id)
        trace_dao.session.close()
        return res