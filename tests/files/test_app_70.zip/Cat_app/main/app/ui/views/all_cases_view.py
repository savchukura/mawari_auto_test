import logging
import os.path

from kivy.uix.screenmanager import Screen

from app.core import loop
from app.services import case_service
from kivy.clock import Clock


# from app import MainApp

class AllCasesView(Screen):
    case_data = []
    case_id = None

    def __init__(self, **kwargs):
        super(AllCasesView, self).__init__(**kwargs)
        # Clock.schedule_once(self.fetch_data())
        # CaseCardsRecycleView

    def fetch_data(self):
        logging.debug("Fetching data for `AllCasesView`")
        logging.debug(f"SQLITE DB FILE: {os.path.isfile('data.db')}")
        case_data, _ = case_service.get_all()
        self.case_data = case_data
        self.ids.all_cases_rv.data = case_data
        # a.ids.all_cases_rv.refresh_from_data(case_data)

    def clicked_case_id(self):
        self.case_id = self
        self.fetch_data()

    def clicked_create_new_case(self):
        manager = self.manager
        manager.current = 'create_case_view'
        manager.transition.direction = "right"

    # def _target(self):
    #     case_data, _ = loop.run_until_complete(self._internal)

    def _internal(self):
        case_data, _ = case_service.get_all()
        self.case_data = case_data
        self.ids.all_cases_rv.data = case_data

    def refresh(self):
        print("B>LYA")
