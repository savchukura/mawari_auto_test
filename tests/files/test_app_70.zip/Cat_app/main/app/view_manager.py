from kivy.uix.screenmanager import ScreenManager


class ViewManager(ScreenManager):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.current_screen.fetch_data()

    def refresh(self, screen_name):
        # self.remove_widget(self.get_screen(screen_name))
        screen = self.get_screen(screen_name)
        screen.refresh()
        # print(screen)


        # screen.refre
