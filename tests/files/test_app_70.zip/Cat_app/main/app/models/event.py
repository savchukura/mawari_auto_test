from uuid import uuid4

from sqlalchemy import (
    Column,
    Integer,
    Text,
    DateTime,
    text,
    ForeignKey,
    String
)
from sqlalchemy.orm import relationship, backref

from app import Base
from app import metadata


class Event(Base):
    __tablename__ = 'events'
    metadata = metadata

    event_id = Column(String(36), primary_key=True, unique=True)
    created_at = Column(DateTime, server_default=text("strftime('%Y-%m-%d %H:%M:%S', 'now')"))
    celery_task_id = Column(String(36))

    memory_pressure_kb = Column(Integer)
    time_spent_seconds = Column(Text)
    event_type = Column(Text)
    status = Column(Text)

    case_id = Column(String(36), ForeignKey('cases.case_id'), nullable=False)
    case = relationship('Case', backref=backref("events", lazy=True))

    def __init__(self, **kwargs):
        super().__init__(id=str(uuid4()), **kwargs)

    def to_dict(self, exclude_keys: tuple = ()):
        exclude_keys = () + exclude_keys

        result = vars(self)
        result.pop('_sa_instance_state', None)
        result['id'] = result.pop('event_id')

        for key in exclude_keys:
            result.pop(key, None)
        return result

    @classmethod
    def filter_by(cls, session, *args, **kwargs):
        return session.query(cls).filter_by(**kwargs)
