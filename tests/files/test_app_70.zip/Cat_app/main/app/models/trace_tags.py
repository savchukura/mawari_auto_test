from uuid import uuid4

from sqlalchemy import (
    Column,
    ForeignKey,
    String,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import UUID

# from sqlalchemy import ForeignKey .
from app import Base
from app import metadata


class TraceTags(Base):
    __tablename__ = 'trace_tags'
    __table_args__ = (UniqueConstraint('trace_id', 'tag_id'),)
    metadata = metadata

    id = Column(String(36), primary_key=True, unique=True)
    trace_id = Column(String(36), ForeignKey('traces.trace_id'))
    tag_id = Column(String(36), ForeignKey('tags.tag_id'))

    def __init__(self, **kwargs):
        super().__init__(id=str(uuid4()), **kwargs)
