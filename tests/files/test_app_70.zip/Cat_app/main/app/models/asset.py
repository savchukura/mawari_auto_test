from uuid import uuid4

from sqlalchemy import (
    Column,
    Text,
    DateTime,
    text,
    ForeignKey,
    UniqueConstraint,
    Float,
    String
)
from sqlalchemy.orm import relationship, backref

from app import Base
from app import metadata


class Asset(Base):
    __tablename__ = 'assets'
    # __table_args__ = (UniqueConstraint('wallet_id', 'symbol', 'chain'),)
    # __table_args__ = (UniqueConstraint('wallet_id', 'symbol'),)

    metadata = metadata

    asset_id = Column(String(36), primary_key=True, unique=True)
    created_at = Column(DateTime, server_default=text("strftime('%Y-%m-%d %H:%M:%S', 'now')"))
    updated_at = Column(DateTime, server_default=text("strftime('%Y-%m-%d %H:%M:%S', 'now')"))
    status = Column(Text, server_default='active')

    wallet_id = Column(String(36), ForeignKey('wallets.wallet_id'), nullable=False)
    wallet = relationship('Wallet', backref=backref("assets", lazy=True))

    chain = Column(Text, nullable=False)
    amount = Column(Float, nullable=False)
    symbol = Column(Text, nullable=False)

    def __init__(self, **kwargs):
        super().__init__(asset_id=str(uuid4()), **kwargs)

    @classmethod
    def get(cls, session, *args, **kwargs):
        return session.query(cls).filter_by(asset_id=args[0]).first()

    def to_dict(self, exclude_keys: tuple = ()):
        exclude_keys = ('case', 'status',) + exclude_keys

        result = vars(self)
        result.pop('_sa_instance_state', None)
        result['id'] = result.pop('asset_id')
        result['amount'] = format(result['amount'], '.18f') if result.get('amount') else "0.0"

        for key in exclude_keys:
            result.pop(key, None)
        return result
