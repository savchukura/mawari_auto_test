import logging
from uuid import uuid4

from sqlalchemy import (
    Column,
    Integer,
    Text,
    DateTime,
    text,
    ForeignKey,
    String,
    Boolean
)
from sqlalchemy.ext.hybrid import hybrid_property
from sqlalchemy.orm import relationship

from app import Base
from app import metadata
from utils import filesystem_tools


class Case(Base):
    __tablename__ = 'cases'
    metadata = metadata

    case_id = Column(String(36), primary_key=True, unique=True)
    created_at = Column(DateTime, server_default=text("strftime('%Y-%m-%d %H:%M:%S', 'now')"))
    updated_at = Column(DateTime, server_default=text("strftime('%Y-%m-%d %H:%M:%S', 'now')"))

    name = Column(Text)
    is_processed = Column(Boolean, server_default='false')

    spectator_id = Column(String(36), ForeignKey('users.id'))
    spectator = relationship('User', foreign_keys=[spectator_id])

    executor_id = Column(String(36), ForeignKey('users.id'), nullable=False)
    executor = relationship('User', foreign_keys=[executor_id])

    status = Column(Text, server_default='active')
    system_hash = Column(Text, nullable=False)
    total_files_num = Column(Integer, nullable=False)
    traces_num = Column(Integer)

    image_scan_status = Column(Text, server_default='new')
    browser_scan_status = Column(Text, server_default='new')
    email_scan_status = Column(Text, server_default='new')
    doc_scan_status = Column(Text, server_default='new')
    usb_scan_status = Column(Text, server_default='new')
    application_scan_status = Column(Text, server_default='new')

    potential_seed_phrases = Column(Integer)
    full_seed_phrases = Column(Integer)

    @hybrid_property
    def full_scan_status(self):
        statuses = (
            self.image_scan_status, self.usb_scan_status,
            self.browser_scan_status, self.doc_scan_status,
            self.email_scan_status,
            self.application_scan_status
        )
        if "new" in statuses:
            return "new"
        if "processing" not in statuses:
            return "processed"
        return "processing"

    def __init__(self, filenames: list[str], **kwargs):
        filesystem_hash = filesystem_tools.get_filesystem_hash(filenames=filenames)
        super().__init__(
            case_id=str(uuid4()),
            system_hash=filesystem_hash, total_files_num=len(filenames),
            **kwargs
        )

    def to_dict(self, exclude_keys: tuple = ()):
        exclude_keys = ('spectator', 'executor', 'status', 'traces') + exclude_keys

        # traces_num = len(self.traces)
        full_scan_status = self.full_scan_status
        try:
            traces_num = len(self.traces)
        except:
            traces_num = 0

        result = vars(self)
        result.pop('_sa_instance_state', None)
        result['id'] = result.pop('case_id')
        # result['traces_num'] = traces_num
        result['full_scan_status'] = full_scan_status
        result['traces_num'] = traces_num

        for key in exclude_keys:
            result.pop(key, None)
        return result

    @classmethod
    def get(cls, session, *args, **kwargs):
        return session.query(cls).filter_by(case_id=args[0]).first()

