from uuid import uuid4

from sqlalchemy import (
    Column,
    Text,
    DateTime,
    text,
    String
)

from app import Base
from app import metadata


class User(Base):
    __tablename__ = 'users'

    metadata = metadata

    id = Column(String(36), primary_key=True, unique=True)
    email = Column(Text, unique=True)
    firebase_uid = Column(Text)
    status = Column(Text, server_default="active")
    created_at = Column(DateTime, server_default=text("strftime('%Y-%m-%d %H:%M:%S', 'now')"))

    # roles = relationship('Role', secondary='user_roles')
    def __init__(self, **kwargs):
        super().__init__(id=str(uuid4()), **kwargs)

    @classmethod
    def get(cls, session, *args, **kwargs):
        return session.query(cls).filter_by(id=args[0]).first()

    def to_dict(self, exclude_keys: tuple = ()):
        exclude_keys = ('_sa_instance_state', 'roles') + exclude_keys
        result = vars(self)
        for key in exclude_keys:
            result.pop(key, None)
        return result
