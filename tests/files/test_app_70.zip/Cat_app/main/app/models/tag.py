from uuid import uuid4

from sqlalchemy import (
    Column,
    Text,
    DateTime,
    text,
    String,
    Boolean
)

from app import Base
from app import metadata
from uuid import uuid4

from sqlalchemy import (
    Column,
    Text,
    DateTime,
    text,
    String,
    Boolean
)

from app import Base
from app import metadata


class Tag(Base):
    __tablename__ = 'tags'
    metadata = metadata

    tag_id = Column(String(36), primary_key=True, unique=True)
    name = Column(Text, nullable=False, unique=True)
    color = Column(Text, unique=True)
    predefined = Column(Boolean, server_default="false")
    created_at = Column(DateTime, server_default=text("now()"))

    def __init__(self, **kwargs):
        super().__init__(tag_id=str(uuid4()), **kwargs)

    def to_dict(self, exclude_keys: tuple = ()):
        exclude_keys = () + exclude_keys

        result = vars(self)
        result.pop('_sa_instance_state', None)
        result['id'] = result.pop('tag_id')

        for key in exclude_keys:
            result.pop(key, None)
        return result
