from uuid import uuid4

from sqlalchemy import (
    Column,
    Integer,
    Text,
    DateTime,
    String
)

from app import Base
from app import metadata


class FileMetadata(Base):
    __tablename__ = 'files_metadata'
    metadata = metadata

    file_metadata_id = Column(String(36), primary_key=True, unique=True)
    filename = Column(Text, nullable=False)
    path = Column(Text, nullable=False)
    mimetype = Column(Text)
    recent_access_at = Column(DateTime)
    recent_modification_at = Column(DateTime)
    recent_metadata_modification_at = Column(DateTime)
    filemode = Column(Text)
    size = Column(Integer)

    def __init__(self, **kwargs):
        super().__init__(file_metadata_id=str(uuid4()), **kwargs)

    def to_dict(self, exclude_keys: tuple = ()):
        exclude_keys = ('',) + exclude_keys

        result = vars(self)
        result.pop('_sa_instance_state', None)
        result['id'] = result.pop('file_metadata_id')

        for key in exclude_keys:
            result.pop(key, None)
        return result
