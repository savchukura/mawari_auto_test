from uuid import uuid4

from sqlalchemy import (
    Column,
    Text,
    DateTime,
    text,
    Float,
    ForeignKey,
    String,
    UniqueConstraint
)
from sqlalchemy.orm import relationship, backref

from app import Base
from app import metadata


class Wallet(Base):
    __tablename__ = 'wallets'
    __table_args__ = (UniqueConstraint('trace_id', 'address'),)

    metadata = metadata

    wallet_id = Column(String(36), primary_key=True, unique=True)
    created_at = Column(DateTime, server_default=text("strftime('%Y-%m-%d %H:%M:%S', 'now')"))
    status = Column(Text, server_default='active')

    trace_id = Column(String(36), ForeignKey('traces.trace_id'), nullable=False)
    trace = relationship('Trace', backref=backref("wallets", lazy=True))
    case_id = Column(String(36), ForeignKey('cases.case_id'), nullable=False)
    case = relationship('Case', backref=backref("wallets", lazy=True))

    file_path = Column(Text)

    # todo: nullable=False
    mnemonic = Column(Text)
    language = Column(Text, nullable=False)
    address = Column(Text, nullable=False)
    balance = Column(Float, nullable=False)
    private_key = Column(Text)
    public_key = Column(Text)

    def __init__(self, **kwargs):
        super().__init__(wallet_id=str(uuid4()), **kwargs)

    @classmethod
    def get(cls, session, *args, **kwargs):
        return session.query(cls).filter_by(wallet_id=args[0]).first()

    def to_dict(self, exclude_keys: tuple = ()):
        exclude_keys = ('case', 'status', 'wallet_id') + exclude_keys

        result = vars(self)
        result.pop('_sa_instance_state', None)
        result['id'] = result.pop('trace_id')
        result['balance'] = f"${format(result['balance'], '.10f')}" if result.get('balance') else '$0.00'

        for key in exclude_keys:
            result.pop(key, None)
        return result
