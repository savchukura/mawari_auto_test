from uuid import uuid4

from sqlalchemy import (
    Column,
    Integer,
    Text,
    DateTime,
    text,
    String
)

from app import Base
from app import metadata


class Log(Base):
    metadata = metadata
    __tablename__ = 'logs'

    log_id = Column(String(36), primary_key=True, unique=True)
    created_at = Column(DateTime, server_default=text("strftime('%Y-%m-%d %H:%M:%S', 'now')"))

    memory_pressure_bytes = Column(Integer, nullable=False)
    time_spent_seconds = Column(Text, nullable=False)
    event_name = Column(Text)
    log_type = Column(Text)
    case_id = Column(String(36))
    details = Column(Text)

    def __init__(self, **kwargs):
        super().__init__(log_id=str(uuid4()), **kwargs)

    def to_dict(self, exclude_keys: tuple = ()):
        exclude_keys = () + exclude_keys

        result = vars(self)
        result.pop('_sa_instance_state', None)
        result['id'] = result.pop('log_id')

        for key in exclude_keys:
            result.pop(key, None)
        return result
