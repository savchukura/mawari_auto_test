from uuid import uuid4

from sqlalchemy import (
    Column,
    Text,
    DateTime,
    text,
    ForeignKey,
    String
)
from sqlalchemy.orm import relationship, backref

from app import Base
from app import metadata


class USBDevice(Base):
    __tablename__ = 'usb_devices'

    metadata = metadata

    usb_id = Column(String(36), primary_key=True, unique=True)
    created_at = Column(DateTime, server_default=text("strftime('%Y-%m-%d %H:%M:%S', 'now')"))
    status = Column(Text, server_default='active')

    trace_id = Column(String(36), ForeignKey('traces.trace_id'), nullable=False)
    trace = relationship('Trace', backref=backref("usb_devices", lazy=True))
    case_id = Column(String(36), ForeignKey('cases.case_id'), nullable=False)
    case = relationship('Case', backref=backref("usb_devices", lazy=True))

    pid = Column(Text, nullable=False)
    vid = Column(Text, nullable=False)
    vendor_name = Column(Text, nullable=False)
    description = Column(Text, nullable=False)
    attribution_url = Column(Text, nullable=False)

    def __init__(self, **kwargs):
        super().__init__(usb_id=str(uuid4()), **kwargs)

    @classmethod
    def get(cls, session, *args, **kwargs):
        return session.query(cls).filter_by(usb_id=args[0]).first()

    def to_dict(self, exclude_keys: tuple = ()):
        exclude_keys = ('case', 'trace') + exclude_keys

        result = vars(self)
        result.pop('_sa_instance_state', None)
        result['id'] = result.pop('usb_id')

        for key in exclude_keys:
            result.pop(key, None)
        return result
