from uuid import uuid4

from sqlalchemy import (
    Column,
    Text,
    DateTime,
    text,
    String
)

from app import Base
from app import metadata


class Email(Base):
    __tablename__ = 'emails'
    metadata = metadata

    email_id = Column(String(36), primary_key=True, unique=True)
    created_at = Column(DateTime, server_default=text("strftime('%Y-%m-%d %H:%M:%S', 'now')"))
    sender = Column(Text, nullable=False)
    receiver = Column(Text, nullable=False)
    subject = Column(Text)
    body = Column(Text)

    # image = Column(Text)
    def __init__(self, **kwargs):
        super().__init__(email_id=str(uuid4()), **kwargs)

    def to_dict(self, exclude_keys: tuple = ()):
        exclude_keys = () + exclude_keys

        result = vars(self)
        result.pop('_sa_instance_state', None)
        result['id'] = result.pop('email_id')

        for key in exclude_keys:
            result.pop(key, None)
        return result
