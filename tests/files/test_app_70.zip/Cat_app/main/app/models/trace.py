import logging
from uuid import uuid4

from sqlalchemy import (
    Column,
    Text,
    DateTime,
    text,
Boolean,
    ForeignKey,
    String
)
from sqlalchemy.orm import relationship, backref

from app import Base
from app import metadata


class Trace(Base):
    __tablename__ = 'traces'
    # __table_args__ = (UniqueConstraint('case_id', 'content', 'trace_type'),)
    metadata = metadata

    trace_id = Column(String(36), primary_key=True, unique=True)
    created_at = Column(DateTime, server_default=text("strftime('%Y-%m-%d %H:%M:%S', 'now')"))

    case_id = Column(String(36), ForeignKey('cases.case_id'), nullable=False)
    case = relationship('Case', backref=backref("traces", lazy=True))

    source = Column(Text, nullable=False)
    trace_type = Column(Text, nullable=False)
    content = Column(Text, nullable=False)

    file_preview_url = Column(Text)
    file_type = Column(Text)
    is_internal = Column(Boolean, server_default='true', nullable=False)
    status = Column(Text, nullable=False)

    file_metadata_id = Column(String(36), ForeignKey('files_metadata.file_metadata_id'))
    file_metadata = relationship('FileMetadata', backref=backref('trace', lazy=True))

    email_id = Column(String(36), ForeignKey('emails.email_id'))
    email = relationship('Email', backref=backref('trace', lazy=True))

    # tags = relationship('Tag', secondary='trace_tags')

    def __init__(self, **kwargs):

        if kwargs.get('trace_id'):
            super().__init__(**kwargs)
        else:
            super().__init__(trace_id=str(uuid4()), **kwargs)

    def __repr__(self):
        return f"{self.trace_id=} {self.trace_type}"

    def to_dict(self, exclude_keys: tuple = ()):
        exclude_keys = ('case', 'wallets', 'usb_devices', 'trace', 'file_metadata', 'email', 'trace_tags') + exclude_keys

        result = vars(self)

        result.pop('_sa_instance_state', None)
        # result['created_at'] = str(result['created_at'])
        result['id'] = result.pop('trace_id')

        for key in exclude_keys:
            result.pop(key, None)
        return result

    @classmethod
    def get(cls, session, *args, **kwargs):
        return session.query(cls).filter_by(trace_id=args[0]).first()
