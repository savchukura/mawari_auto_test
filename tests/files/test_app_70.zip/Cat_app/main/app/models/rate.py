from uuid import uuid4

from sqlalchemy import (
    Column,
    Text,
    DateTime,
    text,
    String,
    Float
)

from app import Base
from app import metadata


class Rate(Base):
    __tablename__ = 'rates'
    metadata = metadata

    rate_id = Column(String(36), primary_key=True, unique=True)
    created_at = Column(DateTime, server_default=text("strftime('%Y-%m-%d %H:%M:%S', 'now')"))

    from_currency_symbol = Column(Text, nullable=False)
    to_currency_symbol = Column(Text, nullable=False)
    rate = Column(Float, nullable=False)

    def __init__(self, **kwargs):
        super().__init__(id=str(uuid4()), **kwargs)

    def to_dict(self, exclude_keys: tuple = ()):
        exclude_keys = () + exclude_keys

        result = vars(self)
        result.pop('_sa_instance_state', None)
        result['id'] = result.pop('rate_id')

        for key in exclude_keys:
            result.pop(key, None)
        return result
