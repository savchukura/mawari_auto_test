from kivy.app import App
from kivy.lang import Builder

from app.core import *
from app.view_manager import ViewManager
from app import ui

# from app.components.traces import *

# from app.components.detailed_case_card import DetailedCaseCardComponent
# from app.components.detailed_trace_card import DetailedTraceView


# Window.minimum_width, Window.minimum_height = 1000, 700
class MainApp(App):
    screen_manager: type(ViewManager)

    def load_all_kv_files(self):
        # Builder.load_file('app/ui/components/cases/case_card_component.kv')
        Builder.load_file('config/colors.kv')
        Builder.load_file('app/ui/utils.kv')


        Builder.load_file('app/ui/components/traces/domains_trace_content.kv')
        Builder.load_file('app/ui/components/traces/wallet_address_trace_content.kv')
        Builder.load_file('app/ui/components/traces/usb_trace_content.kv')
        Builder.load_file('app/ui/components/traces/mnemonic_trace_content.kv')
        Builder.load_file('app/ui/components/sidebar.kv')
        Builder.load_file('app/ui/components/popup.kv')


        Builder.load_file('app/ui/components/traces/detailed_trace_card.kv')
        Builder.load_file('app/ui/components/traces/all_traces_layout.kv')

        Builder.load_file('app/ui/components/cases/detailed_case_card_component.kv')

        Builder.load_file('app/ui/views/all_cases_view.kv')
        Builder.load_file('app/ui/views/selected_case_view.kv')
        Builder.load_file('app/ui/views/selected_trace_view.kv')
        Builder.load_file('app/ui/views/create_case_view.kv')

        Builder.load_file('app/view_manager.kv')
        # Clock.schedule_interval(self.update, 1)

    def build(self):
        self.load_all_kv_files()
        self.screen_manager = ViewManager()

        return self.screen_manager

    # async def kivyCoro(self):
    #     Clock.init_async_lib(lib='asyncio')# This is the method that's gonna launch your kivy app
    #     await self.async_run(async_lib='asyncio')
    #
    # async def base(self):
    #     (done, pending) = await asyncio.wait({self.kivyCoro()},
    #                                          return_when='FIRST_COMPLETED')


app = MainApp()