class BadAPIUsage(Exception):
    code = 400
    description = 'Bad API usage'


class ContentNotFound(Exception):
    code = 404
    description = 'Content not found'


class BadServiceUsage(Exception):
    pass
