import asyncio
import logging
import os
from datetime import datetime

from prometheus_client import CollectorRegistry, Gauge

from sqlalchemy import create_engine, MetaData
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import scoped_session
from sqlalchemy.orm import sessionmaker


from config import Config

metadata = MetaData(naming_convention={
    "ix": 'ix_%(column_0_label)s',
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s"
})
engine = create_engine(Config.SQLALCHEMY_DATABASE_URI, echo=False)
Base = declarative_base(engine)

session_factory = sessionmaker(bind=engine)
Session = scoped_session(session_factory)
# pool = multiprocessing.Pool(processes=1)


registry = CollectorRegistry()

browser_scan_gauge = Gauge('browser_job_time', 'Last time a browser traces to successfully finish', registry=registry)
email_scan_gauge = Gauge('email_job_time', 'Last time a email traces to successfully finish', registry=registry)
usb_scan_gauge = Gauge('usb_job_time', 'Last time a usb traces to successfully finish', registry=registry)
document_scan_gauge = Gauge('document_job_time', 'Last time a document traces to successfully finish',
                            registry=registry)
application_scan_gauge = Gauge('application_job_time', 'Last time a application traces to successfully finish',
                               registry=registry)
balance_db_gauge = Gauge('balance_db_job_time', 'Last time a balance db traces to successfully finish',
                         registry=registry)

root = logging.getLogger()
root.setLevel(logging.DEBUG)
formatter = logging.Formatter('[%(asctime)s]-[%(levelname)s] - %(funcName)s: %(message)s')

error_log_file_fd = open(os.path.join('logs', f'{datetime.now().strftime("%Y-%m-%d")}.error.log'), mode='a')
handler = logging.StreamHandler(error_log_file_fd)
handler.setLevel(logging.ERROR)
handler.setFormatter(formatter)

# root.addHandler(handler)

from utils.filedata_driver import ApplicationDriver
from utils.filedata_driver import BrowserDriver
from utils.seed_phrases_driver import SeedPhrasesDriver
from utils.filedata_driver import EmailDriver
from utils.filedata_driver import USBDriver
from utils.wallet_driver import WalletDriver
from utils.api_driver import APIDriver
from utils.storage_service_driver import StorageServiceDriver

# app.config_from_dict(Config)
# event = Event()
loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)

# ------ Utils factory ---------
# disk_image_driver = DiskImageDriver()
application_driver = ApplicationDriver()
browser_driver = BrowserDriver()
seed_phrases_driver = SeedPhrasesDriver(vars(Config))
email_driver = EmailDriver()
usb_driver = USBDriver()
storage_service_driver = StorageServiceDriver(vars(Config))
wallet_driver = WalletDriver(vars(Config))
api_driver = APIDriver(vars(Config))


